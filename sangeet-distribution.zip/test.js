// Test script for Sangeet Distribution platform
// This script contains functions to test various components of the application

// Test configuration
const config = {
  testUser: {
    email: 'test@example.com',
    password: 'Test@123456',
    name: 'Test User'
  },
  testAdmin: {
    email: 'admin@example.com',
    password: 'Admin@123456',
    name: 'Admin User'
  },
  testRelease: {
    title: 'Test Release',
    artist: 'Test Artist',
    type: 'single',
    genre: 'Pop',
    language: 'English'
  }
};

// UI Testing Functions
const uiTests = {
  // Test landing page components
  testLandingPage: function() {
    console.log('Testing landing page...');
    
    // Check if hero section exists
    const heroSection = document.querySelector('.hero-section');
    if (!heroSection) {
      console.error('❌ Hero section not found');
    } else {
      console.log('✅ Hero section found');
    }
    
    // Check navigation menu
    const navMenu = document.querySelector('.nav-menu');
    if (!navMenu) {
      console.error('❌ Navigation menu not found');
    } else {
      console.log('✅ Navigation menu found');
      
      // Check navigation links
      const navLinks = navMenu.querySelectorAll('a');
      if (navLinks.length < 4) {
        console.error(`❌ Expected at least 4 navigation links, found ${navLinks.length}`);
      } else {
        console.log(`✅ Found ${navLinks.length} navigation links`);
      }
    }
    
    // Check feature sections
    const featureSections = document.querySelectorAll('.feature-section');
    if (featureSections.length === 0) {
      console.error('❌ No feature sections found');
    } else {
      console.log(`✅ Found ${featureSections.length} feature sections`);
    }
    
    // Check pricing section
    const pricingSection = document.querySelector('.pricing-section');
    if (!pricingSection) {
      console.error('❌ Pricing section not found');
    } else {
      console.log('✅ Pricing section found');
    }
    
    // Check footer
    const footer = document.querySelector('footer');
    if (!footer) {
      console.error('❌ Footer not found');
    } else {
      console.log('✅ Footer found');
    }
    
    console.log('Landing page tests completed');
  },
  
  // Test responsive design
  testResponsiveDesign: function() {
    console.log('Testing responsive design...');
    
    const viewportWidth = window.innerWidth;
    console.log(`Current viewport width: ${viewportWidth}px`);
    
    // Check if viewport meta tag exists
    const viewportMeta = document.querySelector('meta[name="viewport"]');
    if (!viewportMeta) {
      console.error('❌ Viewport meta tag not found');
    } else {
      console.log('✅ Viewport meta tag found');
    }
    
    // Check if media queries are applied
    const isMobile = viewportWidth < 768;
    const isTablet = viewportWidth >= 768 && viewportWidth < 1024;
    const isDesktop = viewportWidth >= 1024;
    
    if (isMobile) {
      // Check mobile menu
      const mobileMenu = document.querySelector('.mobile-menu, .hamburger-menu');
      if (!mobileMenu) {
        console.error('❌ Mobile menu not found on mobile viewport');
      } else {
        console.log('✅ Mobile menu found on mobile viewport');
      }
    }
    
    // Check if container has appropriate max-width
    const container = document.querySelector('.container');
    if (container) {
      const containerStyle = window.getComputedStyle(container);
      const maxWidth = containerStyle.getPropertyValue('max-width');
      
      if (isMobile && maxWidth !== '100%' && !maxWidth.includes('px')) {
        console.log('✅ Container has appropriate max-width for mobile');
      } else if (isTablet && maxWidth.includes('px')) {
        console.log('✅ Container has appropriate max-width for tablet');
      } else if (isDesktop && maxWidth.includes('px')) {
        console.log('✅ Container has appropriate max-width for desktop');
      } else {
        console.error(`❌ Container max-width (${maxWidth}) may not be appropriate for current viewport`);
      }
    }
    
    console.log('Responsive design tests completed');
  }
};

// Authentication Testing Functions
const authTests = {
  // Test login functionality
  testLogin: async function() {
    console.log('Testing login functionality...');
    
    if (!firebase || !firebase.auth) {
      console.error('❌ Firebase auth not initialized');
      return;
    }
    
    try {
      // Sign out any existing user
      await firebase.auth().signOut();
      console.log('✅ Successfully signed out existing user');
      
      // Attempt login with test user
      const result = await firebase.auth().signInWithEmailAndPassword(
        config.testUser.email, 
        config.testUser.password
      );
      
      if (result.user) {
        console.log('✅ Successfully logged in test user');
        
        // Check if user is redirected to dashboard
        if (window.location.pathname.includes('/dashboard/')) {
          console.log('✅ User redirected to dashboard');
        } else {
          console.error('❌ User not redirected to dashboard');
        }
        
        // Sign out test user
        await firebase.auth().signOut();
        console.log('✅ Successfully signed out test user');
      } else {
        console.error('❌ Failed to login test user');
      }
    } catch (error) {
      console.error('❌ Login test failed:', error.message);
    }
    
    console.log('Login tests completed');
  },
  
  // Test registration validation
  testRegistrationValidation: function() {
    console.log('Testing registration validation...');
    
    const signupForm = document.getElementById('signupForm');
    if (!signupForm) {
      console.error('❌ Signup form not found');
      return;
    }
    
    // Test email validation
    const emailInput = document.getElementById('signupEmail');
    if (emailInput) {
      // Test invalid email
      emailInput.value = 'invalid-email';
      
      // Check if validation is triggered
      const isEmailValid = emailInput.checkValidity();
      if (!isEmailValid) {
        console.log('✅ Email validation working correctly');
      } else {
        console.error('❌ Email validation not working correctly');
      }
      
      // Reset value
      emailInput.value = '';
    } else {
      console.error('❌ Email input not found');
    }
    
    // Test password validation
    const passwordInput = document.getElementById('signupPassword');
    if (passwordInput) {
      // Test short password
      passwordInput.value = 'short';
      
      // Check if validation is triggered
      const isPasswordValid = passwordInput.checkValidity();
      if (!isPasswordValid) {
        console.log('✅ Password validation working correctly');
      } else {
        console.error('❌ Password validation not working correctly');
      }
      
      // Reset value
      passwordInput.value = '';
    } else {
      console.error('❌ Password input not found');
    }
    
    console.log('Registration validation tests completed');
  }
};

// Dashboard Testing Functions
const dashboardTests = {
  // Test dashboard loading
  testDashboardLoading: function() {
    console.log('Testing dashboard loading...');
    
    // Check if dashboard elements exist
    const dashboardStats = document.querySelector('.dashboard-stats');
    if (!dashboardStats) {
      console.error('❌ Dashboard stats not found');
    } else {
      console.log('✅ Dashboard stats found');
    }
    
    // Check charts
    const charts = document.querySelectorAll('canvas');
    if (charts.length === 0) {
      console.error('❌ No charts found');
    } else {
      console.log(`✅ Found ${charts.length} charts`);
    }
    
    // Check recent releases
    const recentReleases = document.getElementById('recentReleasesList');
    if (!recentReleases) {
      console.error('❌ Recent releases list not found');
    } else {
      console.log('✅ Recent releases list found');
    }
    
    console.log('Dashboard loading tests completed');
  },
  
  // Test release upload form
  testReleaseUploadForm: function() {
    console.log('Testing release upload form...');
    
    const uploadForm = document.getElementById('uploadForm');
    if (!uploadForm) {
      console.error('❌ Upload form not found');
      return;
    }
    
    console.log('✅ Upload form found');
    
    // Check required fields
    const requiredFields = [
      'releaseTitle',
      'primaryArtist',
      'releaseType',
      'genre',
      'language',
      'releaseDate'
    ];
    
    let allFieldsFound = true;
    requiredFields.forEach(fieldId => {
      const field = document.getElementById(fieldId);
      if (!field) {
        console.error(`❌ Required field ${fieldId} not found`);
        allFieldsFound = false;
      }
    });
    
    if (allFieldsFound) {
      console.log('✅ All required fields found');
    }
    
    // Check track upload functionality
    const trackUploadContainer = document.getElementById('trackUploadContainer');
    const addTrackBtn = document.getElementById('addTrackBtn');
    
    if (!trackUploadContainer) {
      console.error('❌ Track upload container not found');
    } else {
      console.log('✅ Track upload container found');
    }
    
    if (!addTrackBtn) {
      console.error('❌ Add track button not found');
    } else {
      console.log('✅ Add track button found');
      
      // Test adding a track
      const initialTrackCount = trackUploadContainer.children.length;
      addTrackBtn.click();
      const newTrackCount = trackUploadContainer.children.length;
      
      if (newTrackCount > initialTrackCount) {
        console.log('✅ Add track functionality working');
      } else {
        console.error('❌ Add track functionality not working');
      }
    }
    
    console.log('Release upload form tests completed');
  }
};

// Admin Panel Testing Functions
const adminTests = {
  // Test admin dashboard loading
  testAdminDashboardLoading: function() {
    console.log('Testing admin dashboard loading...');
    
    // Check if admin dashboard elements exist
    const adminStats = document.querySelector('.admin-stats');
    if (!adminStats) {
      console.error('❌ Admin stats not found');
    } else {
      console.log('✅ Admin stats found');
    }
    
    // Check charts
    const charts = document.querySelectorAll('canvas');
    if (charts.length === 0) {
      console.error('❌ No charts found');
    } else {
      console.log(`✅ Found ${charts.length} charts`);
    }
    
    console.log('Admin dashboard loading tests completed');
  },
  
  // Test user management
  testUserManagement: function() {
    console.log('Testing user management...');
    
    // Check if users table exists
    const usersTable = document.getElementById('usersTable');
    if (!usersTable) {
      console.error('❌ Users table not found');
      return;
    }
    
    console.log('✅ Users table found');
    
    // Check user filters
    const userFilters = document.getElementById('userFilters');
    if (!userFilters) {
      console.error('❌ User filters not found');
    } else {
      console.log('✅ User filters found');
    }
    
    // Check pagination
    const pagination = document.getElementById('usersPagination');
    if (!pagination) {
      console.error('❌ Pagination not found');
    } else {
      console.log('✅ Pagination found');
    }
    
    console.log('User management tests completed');
  },
  
  // Test release approval
  testReleaseApproval: function() {
    console.log('Testing release approval...');
    
    // Check if releases table exists
    const releasesTable = document.getElementById('releasesTable');
    if (!releasesTable) {
      console.error('❌ Releases table not found');
      return;
    }
    
    console.log('✅ Releases table found');
    
    // Check for approval buttons
    const approveButtons = document.querySelectorAll('.approve-release');
    if (approveButtons.length === 0) {
      console.error('❌ No approval buttons found');
    } else {
      console.log(`✅ Found ${approveButtons.length} approval buttons`);
    }
    
    console.log('Release approval tests completed');
  }
};

// Firebase Integration Testing Functions
const firebaseTests = {
  // Test Firebase initialization
  testFirebaseInitialization: function() {
    console.log('Testing Firebase initialization...');
    
    if (!window.firebase) {
      console.error('❌ Firebase not initialized');
      return;
    }
    
    console.log('✅ Firebase initialized');
    
    // Check Firebase services
    if (!firebase.auth) {
      console.error('❌ Firebase Auth not initialized');
    } else {
      console.log('✅ Firebase Auth initialized');
    }
    
    if (!firebase.firestore) {
      console.error('❌ Firebase Firestore not initialized');
    } else {
      console.log('✅ Firebase Firestore initialized');
    }
    
    if (!firebase.storage) {
      console.error('❌ Firebase Storage not initialized');
    } else {
      console.log('✅ Firebase Storage initialized');
    }
    
    console.log('Firebase initialization tests completed');
  },
  
  // Test Firestore operations
  testFirestoreOperations: async function() {
    console.log('Testing Firestore operations...');
    
    if (!firebase.firestore) {
      console.error('❌ Firebase Firestore not initialized');
      return;
    }
    
    try {
      // Test read operation
      const testQuery = await firebase.firestore().collection('users').limit(1).get();
      console.log('✅ Firestore read operation successful');
      
      // Check if query returns results
      if (testQuery.empty) {
        console.log('ℹ️ No users found in database');
      } else {
        console.log('✅ Users found in database');
      }
    } catch (error) {
      console.error('❌ Firestore read operation failed:', error.message);
    }
    
    console.log('Firestore operations tests completed');
  }
};

// Performance Testing Functions
const performanceTests = {
  // Test page load performance
  testPageLoadPerformance: function() {
    console.log('Testing page load performance...');
    
    // Use Performance API if available
    if (window.performance) {
      // Get navigation timing
      const timing = performance.timing;
      const loadTime = timing.loadEventEnd - timing.navigationStart;
      const domReadyTime = timing.domContentLoadedEventEnd - timing.navigationStart;
      
      console.log(`Page load time: ${loadTime}ms`);
      console.log(`DOM ready time: ${domReadyTime}ms`);
      
      // Evaluate performance
      if (loadTime < 2000) {
        console.log('✅ Page load time is excellent (< 2s)');
      } else if (loadTime < 4000) {
        console.log('✅ Page load time is good (< 4s)');
      } else {
        console.error('❌ Page load time is poor (> 4s)');
      }
      
      if (domReadyTime < 1000) {
        console.log('✅ DOM ready time is excellent (< 1s)');
      } else if (domReadyTime < 2000) {
        console.log('✅ DOM ready time is good (< 2s)');
      } else {
        console.error('❌ DOM ready time is poor (> 2s)');
      }
    } else {
      console.error('❌ Performance API not available');
    }
    
    console.log('Page load performance tests completed');
  },
  
  // Test resource optimization
  testResourceOptimization: function() {
    console.log('Testing resource optimization...');
    
    // Check image optimization
    const images = document.querySelectorAll('img');
    let lazyLoadedImages = 0;
    
    images.forEach(img => {
      if (img.loading === 'lazy') {
        lazyLoadedImages++;
      }
    });
    
    console.log(`Total images: ${images.length}`);
    console.log(`Lazy loaded images: ${lazyLoadedImages}`);
    
    if (images.length > 0) {
      const lazyLoadPercentage = (lazyLoadedImages / images.length) * 100;
      if (lazyLoadPercentage >= 90) {
        console.log('✅ Most images are lazy loaded (>= 90%)');
      } else if (lazyLoadPercentage >= 50) {
        console.log('⚠️ Some images are lazy loaded (>= 50%)');
      } else {
        console.error('❌ Few images are lazy loaded (< 50%)');
      }
    }
    
    // Check CSS and JS optimization
    const cssFiles = document.querySelectorAll('link[rel="stylesheet"]');
    const jsFiles = document.querySelectorAll('script[src]');
    
    console.log(`CSS files: ${cssFiles.length}`);
    console.log(`JS files: ${jsFiles.length}`);
    
    if (cssFiles.length > 5) {
      console.error('❌ Too many CSS files (> 5), consider bundling');
    } else {
      console.log('✅ Reasonable number of CSS files');
    }
    
    if (jsFiles.length > 10) {
      console.error('❌ Too many JS files (> 10), consider bundling');
    } else {
      console.log('✅ Reasonable number of JS files');
    }
    
    console.log('Resource optimization tests completed');
  }
};

// Run tests based on current page
function runTests() {
  console.log('Starting Sangeet Distribution tests...');
  
  // Determine current page
  const path = window.location.pathname;
  
  // Run common tests
  firebaseTests.testFirebaseInitialization();
  performanceTests.testPageLoadPerformance();
  performanceTests.testResourceOptimization();
  
  // Run page-specific tests
  if (path === '/' || path.includes('index.html')) {
    console.log('Running landing page tests...');
    uiTests.testLandingPage();
    uiTests.testResponsiveDesign();
  } else if (path.includes('/dashboard/login.html')) {
    console.log('Running login page tests...');
    authTests.testLogin();
  } else if (path.includes('/dashboard/signup.html')) {
    console.log('Running signup page tests...');
    authTests.testRegistrationValidation();
  } else if (path.includes('/dashboard/index.html')) {
    console.log('Running dashboard tests...');
    dashboardTests.testDashboardLoading();
  } else if (path.includes('/dashboard/upload.html')) {
    console.log('Running upload page tests...');
    dashboardTests.testReleaseUploadForm();
  } else if (path.includes('/admin/index.html')) {
    console.log('Running admin dashboard tests...');
    adminTests.testAdminDashboardLoading();
  } else if (path.includes('/admin/users.html')) {
    console.log('Running user management tests...');
    adminTests.testUserManagement();
  } else if (path.includes('/admin/releases.html')) {
    console.log('Running release approval tests...');
    adminTests.testReleaseApproval();
  }
  
  // Run Firestore tests if Firebase is initialized
  if (window.firebase && firebase.firestore) {
    firebaseTests.testFirestoreOperations();
  }
  
  console.log('All tests completed');
}

// Run tests when page is fully loaded
window.addEventListener('load', function() {
  // Add a slight delay to ensure all scripts are loaded
  setTimeout(runTests, 1000);
});

// Export test functions for console use
window.sangeetTests = {
  ui: uiTests,
  auth: authTests,
  dashboard: dashboardTests,
  admin: adminTests,
  firebase: firebaseTests,
  performance: performanceTests,
  runAll: runTests
};
