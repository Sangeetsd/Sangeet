/**
 * Optimization script for Sangeet Distribution platform
 * This script contains functions to optimize performance and fix common issues
 */

// Image optimization function
function optimizeImages() {
  console.log('Running image optimization...');
  
  // Get all images on the page
  const images = document.querySelectorAll('img');
  
  // Loop through images and apply lazy loading
  images.forEach(img => {
    // Add lazy loading attribute if not already present
    if (!img.hasAttribute('loading')) {
      img.setAttribute('loading', 'lazy');
    }
    
    // Ensure alt text for accessibility
    if (!img.hasAttribute('alt') || img.getAttribute('alt') === '') {
      const imgSrc = img.src.split('/').pop();
      img.setAttribute('alt', imgSrc.split('.')[0].replace(/-/g, ' '));
    }
  });
  
  console.log(`Optimized ${images.length} images`);
}

// JavaScript performance optimization
function optimizeJavaScript() {
  console.log('Running JavaScript optimization...');
  
  // Debounce function for search inputs
  window.debounce = function(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  };
  
  // Apply debounce to search inputs
  const searchInputs = document.querySelectorAll('input[type="search"], input.search-input');
  searchInputs.forEach(input => {
    const originalHandler = input.onkeyup;
    if (originalHandler) {
      input.onkeyup = window.debounce(originalHandler, 300);
    }
  });
  
  console.log(`Optimized ${searchInputs.length} search inputs`);
}

// Firebase query optimization
function optimizeFirebaseQueries() {
  console.log('Running Firebase query optimization...');
  
  // Override common Firebase queries with optimized versions
  if (window.FirebaseService) {
    // Original functions
    const originalGetUserReleases = window.FirebaseService.getUserReleases;
    const originalGetAllUsers = window.FirebaseService.getAllUsers;
    const originalGetAllReleases = window.FirebaseService.getAllReleases;
    
    // Optimized getUserReleases with pagination
    window.FirebaseService.getUserReleases = async function(userId, limit = 10, startAfter = null) {
      try {
        let query = firebase.firestore().collection('releases')
          .where('userId', '==', userId)
          .orderBy('createdAt', 'desc')
          .limit(limit);
        
        if (startAfter) {
          query = query.startAfter(startAfter);
        }
        
        const snapshot = await query.get();
        
        const releases = [];
        snapshot.forEach(doc => {
          releases.push({ id: doc.id, ...doc.data() });
        });
        
        const lastDoc = snapshot.docs[snapshot.docs.length - 1];
        
        return { success: true, releases, lastDoc };
      } catch (error) {
        console.error("Error getting user releases:", error);
        return { success: false, error };
      }
    };
    
    // Optimized getAllUsers with pagination
    window.FirebaseService.getAllUsers = async function(limit = 20, startAfter = null, filter = null) {
      try {
        let query = firebase.firestore().collection('users')
          .orderBy('createdAt', 'desc')
          .limit(limit);
        
        if (filter) {
          query = query.where('status', '==', filter);
        }
        
        if (startAfter) {
          query = query.startAfter(startAfter);
        }
        
        const snapshot = await query.get();
        
        const users = [];
        snapshot.forEach(doc => {
          users.push({ id: doc.id, ...doc.data() });
        });
        
        const lastDoc = snapshot.docs[snapshot.docs.length - 1];
        
        return { success: true, users, lastDoc };
      } catch (error) {
        console.error("Error getting all users:", error);
        return { success: false, error };
      }
    };
    
    // Optimized getAllReleases with pagination
    window.FirebaseService.getAllReleases = async function(limit = 20, startAfter = null, status = null) {
      try {
        let query = firebase.firestore().collection('releases')
          .orderBy('createdAt', 'desc')
          .limit(limit);
        
        if (status) {
          query = query.where('status', '==', status);
        }
        
        if (startAfter) {
          query = query.startAfter(startAfter);
        }
        
        const snapshot = await query.get();
        
        const releases = [];
        snapshot.forEach(doc => {
          releases.push({ id: doc.id, ...doc.data() });
        });
        
        const lastDoc = snapshot.docs[snapshot.docs.length - 1];
        
        return { success: true, releases, lastDoc };
      } catch (error) {
        console.error("Error getting all releases:", error);
        return { success: false, error };
      }
    };
    
    console.log('Firebase queries optimized');
  } else {
    console.log('FirebaseService not found, skipping query optimization');
  }
}

// CSS optimization
function optimizeCSS() {
  console.log('Running CSS optimization...');
  
  // Add will-change property to elements with transitions
  const transitionElements = document.querySelectorAll('.card, .modal-container, .nav-item');
  transitionElements.forEach(el => {
    el.style.willChange = 'transform, opacity';
  });
  
  console.log(`Optimized ${transitionElements.length} elements with transitions`);
}

// Form validation optimization
function optimizeFormValidation() {
  console.log('Running form validation optimization...');
  
  // Get all forms
  const forms = document.querySelectorAll('form');
  
  forms.forEach(form => {
    // Skip if already has validation
    if (form.dataset.validationApplied) return;
    
    // Add validation to required fields
    const requiredInputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    
    requiredInputs.forEach(input => {
      // Add validation styling
      input.addEventListener('invalid', function() {
        this.classList.add('validation-error');
      });
      
      // Remove validation styling when fixed
      input.addEventListener('input', function() {
        this.classList.remove('validation-error');
      });
    });
    
    // Mark form as having validation applied
    form.dataset.validationApplied = 'true';
  });
  
  console.log(`Applied validation optimization to ${forms.length} forms`);
}

// Error handling optimization
function optimizeErrorHandling() {
  console.log('Running error handling optimization...');
  
  // Global error handler
  window.addEventListener('error', function(event) {
    console.error('Global error caught:', event.error);
    
    // Log to analytics (if available)
    if (window.firebase && firebase.analytics) {
      firebase.analytics().logEvent('javascript_error', {
        error_message: event.error.message,
        error_stack: event.error.stack,
        url: window.location.href
      });
    }
    
    // Prevent default browser error handling
    event.preventDefault();
    
    // Show user-friendly error message for critical errors
    if (event.error && event.error.message && 
        (event.error.message.includes('Firebase') || 
         event.error.message.includes('auth') || 
         event.error.message.includes('permission'))) {
      showErrorMessage('An error occurred. Please try refreshing the page or contact support if the problem persists.');
    }
    
    return true;
  });
  
  // Function to show user-friendly error message
  window.showErrorMessage = function(message) {
    // Check if error container exists
    let errorContainer = document.getElementById('global-error-container');
    
    // Create error container if it doesn't exist
    if (!errorContainer) {
      errorContainer = document.createElement('div');
      errorContainer.id = 'global-error-container';
      errorContainer.style.position = 'fixed';
      errorContainer.style.top = '20px';
      errorContainer.style.left = '50%';
      errorContainer.style.transform = 'translateX(-50%)';
      errorContainer.style.backgroundColor = '#f44336';
      errorContainer.style.color = 'white';
      errorContainer.style.padding = '12px 24px';
      errorContainer.style.borderRadius = '4px';
      errorContainer.style.zIndex = '9999';
      errorContainer.style.boxShadow = '0 2px 10px rgba(0,0,0,0.2)';
      errorContainer.style.display = 'flex';
      errorContainer.style.alignItems = 'center';
      errorContainer.style.justifyContent = 'space-between';
      
      document.body.appendChild(errorContainer);
    }
    
    // Set error message
    errorContainer.innerHTML = `
      <span>${message}</span>
      <button style="background: none; border: none; color: white; margin-left: 16px; cursor: pointer; font-size: 20px;">&times;</button>
    `;
    
    // Add close button functionality
    const closeButton = errorContainer.querySelector('button');
    closeButton.addEventListener('click', function() {
      errorContainer.style.display = 'none';
    });
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      errorContainer.style.display = 'none';
    }, 5000);
  };
  
  console.log('Error handling optimized');
}

// Run all optimizations when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('Running Sangeet Distribution optimizations...');
  
  // Run optimizations
  optimizeImages();
  optimizeJavaScript();
  optimizeCSS();
  optimizeFormValidation();
  optimizeErrorHandling();
  
  // Run Firebase optimizations after Firebase is initialized
  if (window.firebase) {
    optimizeFirebaseQueries();
  } else {
    // Wait for Firebase to be initialized
    const checkFirebase = setInterval(() => {
      if (window.firebase) {
        optimizeFirebaseQueries();
        clearInterval(checkFirebase);
      }
    }, 500);
    
    // Stop checking after 10 seconds
    setTimeout(() => {
      clearInterval(checkFirebase);
    }, 10000);
  }
  
  console.log('All optimizations completed');
});
