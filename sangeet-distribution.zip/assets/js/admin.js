// Admin panel functionality for Sangeet Distribution
document.addEventListener('DOMContentLoaded', function() {
    // Import Firebase configuration
    // Firebase config is loaded in the main HTML file
    
    // DOM Elements - Admin Dashboard
    const totalUsersElement = document.getElementById('totalUsers');
    const totalReleasesElement = document.getElementById('totalReleases');
    const pendingReleasesElement = document.getElementById('pendingReleases');
    const totalRevenueElement = document.getElementById('totalRevenue');
    
    // DOM Elements - Charts
    const releasesChartElement = document.getElementById('releasesChart');
    const revenueChartElement = document.getElementById('revenueChart');
    const userGrowthChartElement = document.getElementById('userGrowthChart');
    
    // DOM Elements - User Management
    const usersTableElement = document.getElementById('usersTable');
    const usersPaginationElement = document.getElementById('usersPagination');
    const userSearchInput = document.getElementById('userSearchInput');
    const userSearchBtn = document.getElementById('userSearchBtn');
    const userStatusFilter = document.getElementById('userStatusFilter');
    
    // DOM Elements - Release Management
    const releasesTableElement = document.getElementById('releasesTable');
    const releasesPaginationElement = document.getElementById('releasesPagination');
    const releaseSearchInput = document.getElementById('releaseSearchInput');
    const releaseSearchBtn = document.getElementById('releaseSearchBtn');
    const releaseStatusFilter = document.getElementById('releaseStatusFilter');
    
    // DOM Elements - DSP Management
    const dspsTableElement = document.getElementById('dspsTable');
    const addDspBtn = document.getElementById('addDspBtn');
    const dspForm = document.getElementById('dspForm');
    
    // Variables
    let currentUser = null;
    let isAdmin = false;
    let currentUserPage = 1;
    let totalUserPages = 1;
    let userPageSize = 10;
    let currentReleasePage = 1;
    let totalReleasePages = 1;
    let releasePageSize = 10;
    
    // Check authentication state
    firebase.auth().onAuthStateChanged(async function(user) {
        if (user) {
            // User is signed in
            currentUser = user;
            
            // Check if user is admin
            try {
                const userDoc = await firebase.firestore().collection('users').doc(user.uid).get();
                
                if (userDoc.exists) {
                    const userData = userDoc.data();
                    isAdmin = userData.role === 'admin';
                    
                    if (!isAdmin) {
                        // Redirect to user dashboard
                        window.location.href = '../dashboard/index.html';
                        return;
                    }
                    
                    // Initialize admin dashboard
                    initializeAdminDashboard();
                } else {
                    // Redirect to user dashboard
                    window.location.href = '../dashboard/index.html';
                }
            } catch (error) {
                console.error('Error checking admin status:', error);
                // Redirect to user dashboard
                window.location.href = '../dashboard/index.html';
            }
        } else {
            // No user is signed in, redirect to login
            window.location.href = '../dashboard/login.html';
        }
    });
    
    // Initialize Admin Dashboard
    function initializeAdminDashboard() {
        // Check which page we're on
        const path = window.location.pathname;
        
        if (path.includes('index.html') || path.endsWith('/admin/')) {
            // Load dashboard data
            loadDashboardData();
            
            // Initialize charts
            initializeCharts();
        } else if (path.includes('users.html')) {
            // Load users
            loadUsers();
            
            // Initialize user filters
            initializeUserFilters();
        } else if (path.includes('releases.html')) {
            // Load releases
            loadReleases();
            
            // Initialize release filters
            initializeReleaseFilters();
        } else if (path.includes('royalties.html')) {
            // Load royalty data
            loadRoyaltyData();
        } else if (path.includes('dsp-integration.html')) {
            // Load DSPs
            loadDSPs();
            
            // Initialize DSP form
            initializeDSPForm();
        }
    }
    
    // Load Dashboard Data
    async function loadDashboardData() {
        try {
            // Get total users
            const usersSnapshot = await firebase.firestore().collection('users').get();
            const totalUsers = usersSnapshot.size;
            
            if (totalUsersElement) {
                totalUsersElement.textContent = totalUsers;
            }
            
            // Get total releases
            const releasesSnapshot = await firebase.firestore().collection('releases').get();
            const totalReleases = releasesSnapshot.size;
            
            if (totalReleasesElement) {
                totalReleasesElement.textContent = totalReleases;
            }
            
            // Get pending releases
            const pendingReleasesSnapshot = await firebase.firestore().collection('releases')
                .where('status', '==', 'in_review')
                .get();
            
            const pendingReleases = pendingReleasesSnapshot.size;
            
            if (pendingReleasesElement) {
                pendingReleasesElement.textContent = pendingReleases;
            }
            
            // Get total revenue
            const royaltiesSnapshot = await firebase.firestore().collection('royalties').get();
            
            let totalRevenue = 0;
            
            royaltiesSnapshot.forEach(doc => {
                const royaltyData = doc.data();
                totalRevenue += royaltyData.amount || 0;
            });
            
            if (totalRevenueElement) {
                totalRevenueElement.textContent = formatCurrency(totalRevenue);
            }
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        }
    }
    
    // Initialize Charts
    async function initializeCharts() {
        try {
            // Get release data for charts
            const releasesSnapshot = await firebase.firestore().collection('releases')
                .orderBy('createdAt', 'asc')
                .get();
            
            // Get user data for charts
            const usersSnapshot = await firebase.firestore().collection('users')
                .orderBy('createdAt', 'asc')
                .get();
            
            // Get royalty data for charts
            const royaltiesSnapshot = await firebase.firestore().collection('royalties')
                .orderBy('period', 'asc')
                .get();
            
            // Process release data
            const releaseData = {};
            
            releasesSnapshot.forEach(doc => {
                const releaseInfo = doc.data();
                
                if (releaseInfo.createdAt) {
                    const date = new Date(releaseInfo.createdAt.toDate());
                    const month = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                    
                    if (!releaseData[month]) {
                        releaseData[month] = 0;
                    }
                    
                    releaseData[month]++;
                }
            });
            
            // Process user data
            const userData = {};
            
            usersSnapshot.forEach(doc => {
                const userInfo = doc.data();
                
                if (userInfo.createdAt) {
                    const date = new Date(userInfo.createdAt.toDate());
                    const month = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                    
                    if (!userData[month]) {
                        userData[month] = 0;
                    }
                    
                    userData[month]++;
                }
            });
            
            // Process royalty data
            const revenueData = {};
            
            royaltiesSnapshot.forEach(doc => {
                const royaltyInfo = doc.data();
                
                if (royaltyInfo.period) {
                    const year = royaltyInfo.period.substring(0, 4);
                    const month = royaltyInfo.period.substring(5, 7);
                    const date = new Date(year, month - 1);
                    const formattedMonth = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                    
                    if (!revenueData[formattedMonth]) {
                        revenueData[formattedMonth] = 0;
                    }
                    
                    revenueData[formattedMonth] += royaltyInfo.amount || 0;
                }
            });
            
            // Create releases chart
            if (releasesChartElement) {
                const releaseMonths = Object.keys(releaseData).slice(-12);
                const releaseCounts = releaseMonths.map(month => releaseData[month]);
                
                const releasesCtx = releasesChartElement.getContext('2d');
                new Chart(releasesCtx, {
                    type: 'bar',
                    data: {
                        labels: releaseMonths,
                        datasets: [{
                            label: 'New Releases',
                            data: releaseCounts,
                            backgroundColor: 'rgba(138, 79, 255, 0.7)',
                            borderWidth: 0,
                            borderRadius: 5
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    precision: 0
                                }
                            }
                        }
                    }
                });
            }
            
            // Create revenue chart
            if (revenueChartElement) {
                const revenueMonths = Object.keys(revenueData).slice(-12);
                const revenueAmounts = revenueMonths.map(month => revenueData[month]);
                
                const revenueCtx = revenueChartElement.getContext('2d');
                new Chart(revenueCtx, {
                    type: 'line',
                    data: {
                        labels: revenueMonths,
                        datasets: [{
                            label: 'Revenue',
                            data: revenueAmounts,
                            backgroundColor: 'rgba(0, 168, 225, 0.1)',
                            borderColor: 'rgba(0, 168, 225, 1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return formatCurrency(context.raw);
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return formatCurrency(value, true);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            // Create user growth chart
            if (userGrowthChartElement) {
                const userMonths = Object.keys(userData).slice(-12);
                const userCounts = userMonths.map(month => userData[month]);
                
                // Calculate cumulative user count
                const cumulativeUserCounts = [];
                let cumulativeCount = 0;
                
                userCounts.forEach(count => {
                    cumulativeCount += count;
                    cumulativeUserCounts.push(cumulativeCount);
                });
                
                const userGrowthCtx = userGrowthChartElement.getContext('2d');
                new Chart(userGrowthCtx, {
                    type: 'line',
                    data: {
                        labels: userMonths,
                        datasets: [{
                            label: 'Total Users',
                            data: cumulativeUserCounts,
                            backgroundColor: 'rgba(255, 87, 34, 0.1)',
                            borderColor: 'rgba(255, 87, 34, 1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    precision: 0
                                }
                            }
                        }
                    }
                });
            }
        } catch (error) {
            console.error('Error initializing charts:', error);
        }
    }
    
    // Load Users
    async function loadUsers(filter = 'all', searchQuery = '') {
        if (!usersTableElement) return;
        
        try {
            // Show loading state
            usersTableElement.innerHTML = '<tr><td colspan="6" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading users...</td></tr>';
            
            // Build query
            let query = firebase.firestore().collection('users')
                .orderBy('createdAt', 'desc');
            
            // Apply filter
            if (filter !== 'all') {
                query = query.where('status', '==', filter);
            }
            
            // Apply search query
            // Note: Firestore doesn't support text search directly
            // For a real app, you would need to use a service like Algolia
            // This is a simplified approach for demo purposes
            
            // Get total count for pagination
            const countSnapshot = await query.get();
            const totalUsers = countSnapshot.size;
            totalUserPages = Math.ceil(totalUsers / userPageSize);
            
            // Apply pagination
            const startIndex = (currentUserPage - 1) * userPageSize;
            query = query.limit(userPageSize);
            
            if (startIndex > 0) {
                const lastVisibleDoc = await getDocAtIndex(query, startIndex - 1);
                if (lastVisibleDoc) {
                    query = query.startAfter(lastVisibleDoc);
                }
            }
            
            // Get users
            const usersSnapshot = await query.get();
            
            if (usersSnapshot.empty) {
                usersTableElement.innerHTML = '<tr><td colspan="6" class="text-center">No users found</td></tr>';
                updateUserPagination(0);
                return;
            }
            
            let html = '';
            
            usersSnapshot.forEach(doc => {
                const userData = doc.data();
                const userId = doc.id;
                
                // Format date
                const createdAt = userData.createdAt ? new Date(userData.createdAt.toDate()) : new Date();
                const formattedDate = createdAt.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Get status badge class
                let statusBadgeClass = '';
                switch (userData.status) {
                    case 'active':
                        statusBadgeClass = 'approved';
                        break;
                    case 'suspended':
                        statusBadgeClass = 'rejected';
                        break;
                    case 'pending':
                        statusBadgeClass = 'review';
                        break;
                    default:
                        statusBadgeClass = 'approved';
                }
                
                html += `
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center;">
                                <div class="user-avatar">
                                    ${userData.name ? userData.name.charAt(0).toUpperCase() : 'U'}
                                </div>
                                <div>
                                    <div style="font-weight: 600;">${userData.name || 'Unknown User'}</div>
                                    <div style="font-size: 0.8rem; color: #666;">${userData.email || 'No email'}</div>
                                </div>
                            </div>
                        </td>
                        <td>${userData.role || 'artist'}</td>
                        <td>${formattedDate}</td>
                        <td><span class="status-badge ${statusBadgeClass}">${userData.status || 'active'}</span></td>
                        <td>${userData.isVerified ? '<span class="verified-badge"><i class="fas fa-check-circle"></i> Verified</span>' : 'Not Verified'}</td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn view-user" data-id="${userId}" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit-user" data-id="${userId}" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                ${userData.status === 'active' ? `
                                    <button class="action-btn suspend-user" data-id="${userId}" title="Suspend">
                                        <i class="fas fa-ban"></i>
                                    </button>
                                ` : `
                                    <button class="action-btn activate-user" data-id="${userId}" title="Activate">
                                        <i class="fas fa-check"></i>
                                    </button>
                                `}
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            usersTableElement.innerHTML = html;
            
            // Add event listeners for action buttons
            const viewButtons = document.querySelectorAll('.view-user');
            viewButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const userId = this.dataset.id;
                    viewUser(userId);
                });
            });
            
            const editButtons = document.querySelectorAll('.edit-user');
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const userId = this.dataset.id;
                    editUser(userId);
                });
            });
            
            const suspendButtons = document.querySelectorAll('.suspend-user');
            suspendButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const userId = this.dataset.id;
                    if (confirm('Are you sure you want to suspend this user?')) {
                        updateUserStatus(userId, 'suspended');
                    }
                });
            });
            
            const activateButtons = document.querySelectorAll('.activate-user');
            activateButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const userId = this.dataset.id;
                    if (confirm('Are you sure you want to activate this user?')) {
                        updateUserStatus(userId, 'active');
                    }
                });
            });
            
            // Update pagination
            updateUserPagination(totalUsers);
        } catch (error) {
            console.error('Error loading users:', error);
            usersTableElement.innerHTML = '<tr><td colspan="6" class="text-center">Error loading users</td></tr>';
        }
    }
    
    // Update User Pagination
    function updateUserPagination(totalUsers) {
        if (!usersPaginationElement) return;
        
        if (totalUsers === 0) {
            usersPaginationElement.style.display = 'none';
            return;
        }
        
        usersPaginationElement.style.display = 'flex';
        
        let html = '';
        
        // Previous button
        html += `
            <div class="pagination-item ${currentUserPage === 1 ? 'disabled' : ''}" data-page="prev">
                <i class="fas fa-chevron-left"></i>
            </div>
        `;
        
        // Page numbers
        const maxPages = Math.min(totalUserPages, 5);
        let startPage = Math.max(1, currentUserPage - 2);
        let endPage = Math.min(startPage + maxPages - 1, totalUserPages);
        
        if (endPage - startPage < maxPages - 1) {
            startPage = Math.max(1, endPage - maxPages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <div class="pagination-item ${i === currentUserPage ? 'active' : ''}" data-page="${i}">
                    ${i}
                </div>
            `;
        }
        
        // Next button
        html += `
            <div class="pagination-item ${currentUserPage === totalUserPages ? 'disabled' : ''}" data-page="next">
                <i class="fas fa-chevron-right"></i>
            </div>
        `;
        
        usersPaginationElement.innerHTML = html;
        
        // Add event listeners for pagination
        const paginationItems = document.querySelectorAll('.pagination-item');
        paginationItems.forEach(item => {
            item.addEventListener('click', function() {
                if (this.classList.contains('disabled')) return;
                
                const page = this.dataset.page;
                
                if (page === 'prev') {
                    currentUserPage = Math.max(1, currentUserPage - 1);
                } else if (page === 'next') {
                    currentUserPage = Math.min(totalUserPages, currentUserPage + 1);
                } else {
                    currentUserPage = parseInt(page);
                }
                
                // Reload users with current filter and search
                const filter = userStatusFilter ? userStatusFilter.value : 'all';
                const searchQuery = userSearchInput ? userSearchInput.value.trim() : '';
                
                loadUsers(filter, searchQuery);
            });
        });
    }
    
    // Initialize User Filters
    function initializeUserFilters() {
        if (userStatusFilter) {
            userStatusFilter.addEventListener('change', function() {
                currentUserPage = 1;
                const searchQuery = userSearchInput ? userSearchInput.value.trim() : '';
                loadUsers(this.value, searchQuery);
            });
        }
        
        if (userSearchBtn && userSearchInput) {
            userSearchBtn.addEventListener('click', function() {
                currentUserPage = 1;
                const filter = userStatusFilter ? userStatusFilter.value : 'all';
                loadUsers(filter, userSearchInput.value.trim());
            });
            
            userSearchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    currentUserPage = 1;
                    const filter = userStatusFilter ? userStatusFilter.value : 'all';
                    loadUsers(filter, this.value.trim());
                }
            });
        }
    }
    
    // View User
    async function viewUser(userId) {
        try {
            // Get user data
            const userDoc = await firebase.firestore().collection('users').doc(userId).get();
            
            if (!userDoc.exists) {
                alert('User not found.');
                return;
            }
            
            const userData = userDoc.data();
            
            // Format date
            const createdAt = userData.createdAt ? new Date(userData.createdAt.toDate()) : new Date();
            const formattedDate = createdAt.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            // Get user releases
            const releasesSnapshot = await firebase.firestore().collection('releases')
                .where('userId', '==', userId)
                .orderBy('createdAt', 'desc')
                .limit(5)
                .get();
            
            let releasesHtml = '';
            
            if (releasesSnapshot.empty) {
                releasesHtml = '<p>No releases found</p>';
            } else {
                releasesHtml = '<div class="user-releases-list">';
                
                releasesSnapshot.forEach(doc => {
                    const releaseData = doc.data();
                    
                    // Format date
                    const releaseDate = releaseData.createdAt ? new Date(releaseData.createdAt.toDate()) : new Date();
                    const formattedReleaseDate = releaseDate.toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'short', 
                        day: 'numeric'
                    });
                    
                    // Get status badge class
                    let statusBadgeClass = '';
                    switch (releaseData.status) {
                        case 'draft':
                            statusBadgeClass = 'draft';
                            break;
                        case 'in_review':
                            statusBadgeClass = 'review';
                            break;
                        case 'approved':
                            statusBadgeClass = 'approved';
                            break;
                        case 'rejected':
                            statusBadgeClass = 'rejected';
                            break;
                        case 'changes_requested':
                            statusBadgeClass = 'changes';
                            break;
                        default:
                            statusBadgeClass = 'draft';
                    }
                    
                    releasesHtml += `
                        <div class="user-release-item">
                            <div class="release-cover">
                                <img src="${releaseData.coverArtURL || '../assets/images/default-cover.jpg'}" alt="${releaseData.title}">
                            </div>
                            <div class="release-info">
                                <div class="release-title">${releaseData.title || 'Untitled Release'}</div>
                                <div class="release-artist">${releaseData.primaryArtist || 'Unknown Artist'}</div>
                                <div class="release-meta">
                                    <span>${formattedReleaseDate}</span>
                                    <span class="status-badge ${statusBadgeClass}">${formatStatus(releaseData.status)}</span>
                                </div>
                            </div>
                        </div>
                    `;
                });
                
                releasesHtml += '</div>';
            }
            
            // Create modal content
            let modalContent = `
                <div class="user-details-modal">
                    <div class="user-details-header">
                        <div class="user-avatar large">
                            ${userData.name ? userData.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                        <div class="user-info">
                            <h2>${userData.name || 'Unknown User'}</h2>
                            <div class="user-email">${userData.email || 'No email'}</div>
                            <div class="user-meta">
                                <span class="user-role">${userData.role || 'artist'}</span>
                                <span class="status-badge ${userData.status === 'active' ? 'approved' : 'rejected'}">${userData.status || 'active'}</span>
                                ${userData.isVerified ? '<span class="verified-badge"><i class="fas fa-check-circle"></i> Verified</span>' : '<span class="not-verified">Not Verified</span>'}
                            </div>
                        </div>
                    </div>
                    
                    <div class="user-details-section">
                        <h3>Account Information</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">User ID</div>
                                <div class="info-value">${userId}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Created On</div>
                                <div class="info-value">${formattedDate}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Last Login</div>
                                <div class="info-value">${userData.lastLogin ? new Date(userData.lastLogin.toDate()).toLocaleDateString('en-US', { 
                                    year: 'numeric', 
                                    month: 'short', 
                                    day: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                }) : 'Never'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Phone</div>
                                <div class="info-value">${userData.phone || 'Not provided'}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="user-details-section">
                        <h3>Recent Releases</h3>
                        ${releasesHtml}
                    </div>
                    
                    <div class="user-details-footer">
                        <button class="btn btn-primary close-modal">Close</button>
                        <button class="btn btn-secondary edit-user-btn" data-id="${userId}">Edit User</button>
                        ${userData.status === 'active' ? `
                            <button class="btn btn-danger suspend-user-btn" data-id="${userId}">Suspend User</button>
                        ` : `
                            <button class="btn btn-success activate-user-btn" data-id="${userId}">Activate User</button>
                        `}
                    </div>
                </div>
            `;
            
            // Create modal
            const modalOverlay = document.createElement('div');
            modalOverlay.className = 'modal-overlay';
            modalOverlay.innerHTML = `
                <div class="modal-container">
                    ${modalContent}
                </div>
            `;
            
            document.body.appendChild(modalOverlay);
            
            // Add event listeners for buttons
            const closeButton = modalOverlay.querySelector('.close-modal');
            closeButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
            });
            
            const editButton = modalOverlay.querySelector('.edit-user-btn');
            editButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
                editUser(userId);
            });
            
            const suspendButton = modalOverlay.querySelector('.suspend-user-btn');
            if (suspendButton) {
                suspendButton.addEventListener('click', function() {
                    if (confirm('Are you sure you want to suspend this user?')) {
                        document.body.removeChild(modalOverlay);
                        updateUserStatus(userId, 'suspended');
                    }
                });
            }
            
            const activateButton = modalOverlay.querySelector('.activate-user-btn');
            if (activateButton) {
                activateButton.addEventListener('click', function() {
                    if (confirm('Are you sure you want to activate this user?')) {
                        document.body.removeChild(modalOverlay);
                        updateUserStatus(userId, 'active');
                    }
                });
            }
            
            // Close modal when clicking outside
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    document.body.removeChild(modalOverlay);
                }
            });
        } catch (error) {
            console.error('Error viewing user:', error);
            alert('An error occurred while loading user details. Please try again.');
        }
    }
    
    // Edit User
    async function editUser(userId) {
        try {
            // Get user data
            const userDoc = await firebase.firestore().collection('users').doc(userId).get();
            
            if (!userDoc.exists) {
                alert('User not found.');
                return;
            }
            
            const userData = userDoc.data();
            
            // Create modal content
            let modalContent = `
                <div class="edit-user-modal">
                    <div class="edit-user-header">
                        <h2>Edit User</h2>
                    </div>
                    
                    <div class="edit-user-form">
                        <div class="form-group">
                            <label for="editUserName">Name</label>
                            <input type="text" id="editUserName" class="form-control" value="${userData.name || ''}">
                        </div>
                        
                        <div class="form-group">
                            <label for="editUserEmail">Email</label>
                            <input type="email" id="editUserEmail" class="form-control" value="${userData.email || ''}" disabled>
                        </div>
                        
                        <div class="form-group">
                            <label for="editUserPhone">Phone</label>
                            <input type="text" id="editUserPhone" class="form-control" value="${userData.phone || ''}">
                        </div>
                        
                        <div class="form-group">
                            <label for="editUserRole">Role</label>
                            <select id="editUserRole" class="form-control">
                                <option value="artist" ${userData.role === 'artist' ? 'selected' : ''}>Artist</option>
                                <option value="admin" ${userData.role === 'admin' ? 'selected' : ''}>Admin</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="editUserStatus">Status</label>
                            <select id="editUserStatus" class="form-control">
                                <option value="active" ${userData.status === 'active' ? 'selected' : ''}>Active</option>
                                <option value="suspended" ${userData.status === 'suspended' ? 'selected' : ''}>Suspended</option>
                                <option value="pending" ${userData.status === 'pending' ? 'selected' : ''}>Pending</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="editUserVerified">Verified</label>
                            <select id="editUserVerified" class="form-control">
                                <option value="true" ${userData.isVerified ? 'selected' : ''}>Yes</option>
                                <option value="false" ${!userData.isVerified ? 'selected' : ''}>No</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="edit-user-footer">
                        <button class="btn btn-secondary cancel-edit">Cancel</button>
                        <button class="btn btn-primary save-user" data-id="${userId}">Save Changes</button>
                    </div>
                </div>
            `;
            
            // Create modal
            const modalOverlay = document.createElement('div');
            modalOverlay.className = 'modal-overlay';
            modalOverlay.innerHTML = `
                <div class="modal-container">
                    ${modalContent}
                </div>
            `;
            
            document.body.appendChild(modalOverlay);
            
            // Add event listeners for buttons
            const cancelButton = modalOverlay.querySelector('.cancel-edit');
            cancelButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
            });
            
            const saveButton = modalOverlay.querySelector('.save-user');
            saveButton.addEventListener('click', function() {
                // Get form values
                const name = document.getElementById('editUserName').value.trim();
                const phone = document.getElementById('editUserPhone').value.trim();
                const role = document.getElementById('editUserRole').value;
                const status = document.getElementById('editUserStatus').value;
                const isVerified = document.getElementById('editUserVerified').value === 'true';
                
                // Validate form
                if (!name) {
                    alert('Please enter a name.');
                    return;
                }
                
                // Update user
                updateUser(userId, {
                    name,
                    phone,
                    role,
                    status,
                    isVerified,
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                });
                
                // Close modal
                document.body.removeChild(modalOverlay);
            });
            
            // Close modal when clicking outside
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    document.body.removeChild(modalOverlay);
                }
            });
        } catch (error) {
            console.error('Error editing user:', error);
            alert('An error occurred while loading user details. Please try again.');
        }
    }
    
    // Update User
    async function updateUser(userId, userData) {
        try {
            // Update user in Firestore
            await firebase.firestore().collection('users').doc(userId).update(userData);
            
            // Reload users
            loadUsers();
            
            alert('User updated successfully!');
        } catch (error) {
            console.error('Error updating user:', error);
            alert('An error occurred while updating the user. Please try again.');
        }
    }
    
    // Update User Status
    async function updateUserStatus(userId, status) {
        try {
            // Update user status in Firestore
            await firebase.firestore().collection('users').doc(userId).update({
                status: status,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            
            // Reload users
            loadUsers();
            
            alert(`User ${status === 'active' ? 'activated' : 'suspended'} successfully!`);
        } catch (error) {
            console.error('Error updating user status:', error);
            alert('An error occurred while updating the user status. Please try again.');
        }
    }
    
    // Load Releases
    async function loadReleases(filter = 'all', searchQuery = '') {
        if (!releasesTableElement) return;
        
        try {
            // Show loading state
            releasesTableElement.innerHTML = '<tr><td colspan="6" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading releases...</td></tr>';
            
            // Build query
            let query = firebase.firestore().collection('releases')
                .orderBy('createdAt', 'desc');
            
            // Apply filter
            if (filter !== 'all') {
                query = query.where('status', '==', filter);
            }
            
            // Get total count for pagination
            const countSnapshot = await query.get();
            const totalReleases = countSnapshot.size;
            totalReleasePages = Math.ceil(totalReleases / releasePageSize);
            
            // Apply pagination
            const startIndex = (currentReleasePage - 1) * releasePageSize;
            query = query.limit(releasePageSize);
            
            if (startIndex > 0) {
                const lastVisibleDoc = await getDocAtIndex(query, startIndex - 1);
                if (lastVisibleDoc) {
                    query = query.startAfter(lastVisibleDoc);
                }
            }
            
            // Get releases
            const releasesSnapshot = await query.get();
            
            if (releasesSnapshot.empty) {
                releasesTableElement.innerHTML = '<tr><td colspan="6" class="text-center">No releases found</td></tr>';
                updateReleasePagination(0);
                return;
            }
            
            let html = '';
            
            releasesSnapshot.forEach(doc => {
                const releaseData = doc.data();
                const releaseId = doc.id;
                
                // Format date
                const createdAt = releaseData.createdAt ? new Date(releaseData.createdAt.toDate()) : new Date();
                const formattedDate = createdAt.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Get status badge class
                let statusBadgeClass = '';
                switch (releaseData.status) {
                    case 'draft':
                        statusBadgeClass = 'draft';
                        break;
                    case 'in_review':
                        statusBadgeClass = 'review';
                        break;
                    case 'approved':
                        statusBadgeClass = 'approved';
                        break;
                    case 'rejected':
                        statusBadgeClass = 'rejected';
                        break;
                    case 'changes_requested':
                        statusBadgeClass = 'changes';
                        break;
                    default:
                        statusBadgeClass = 'draft';
                }
                
                html += `
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center;">
                                <img src="${releaseData.coverArtURL || '../assets/images/default-cover.jpg'}" alt="${releaseData.title}" style="width: 40px; height: 40px; border-radius: 4px; margin-right: 10px;">
                                <div>
                                    <div style="font-weight: 600;">${releaseData.title || 'Untitled Release'}</div>
                                    <div style="font-size: 0.8rem; color: #666;">${releaseData.primaryArtist || 'Unknown Artist'}</div>
                                </div>
                            </div>
                        </td>
                        <td>${releaseData.releaseType || 'Single'}</td>
                        <td>${formattedDate}</td>
                        <td><span class="status-badge ${statusBadgeClass}">${formatStatus(releaseData.status)}</span></td>
                        <td>${releaseData.trackCount || 0} tracks</td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn view-release" data-id="${releaseId}" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </button>
                                ${releaseData.status === 'in_review' ? `
                                    <button class="action-btn approve-release" data-id="${releaseId}" title="Approve">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="action-btn reject-release" data-id="${releaseId}" title="Reject">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <button class="action-btn request-changes" data-id="${releaseId}" title="Request Changes">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                ` : ''}
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            releasesTableElement.innerHTML = html;
            
            // Add event listeners for action buttons
            const viewButtons = document.querySelectorAll('.view-release');
            viewButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const releaseId = this.dataset.id;
                    viewRelease(releaseId);
                });
            });
            
            const approveButtons = document.querySelectorAll('.approve-release');
            approveButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const releaseId = this.dataset.id;
                    if (confirm('Are you sure you want to approve this release?')) {
                        approveRelease(releaseId);
                    }
                });
            });
            
            const rejectButtons = document.querySelectorAll('.reject-release');
            rejectButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const releaseId = this.dataset.id;
                    rejectRelease(releaseId);
                });
            });
            
            const requestChangesButtons = document.querySelectorAll('.request-changes');
            requestChangesButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const releaseId = this.dataset.id;
                    requestChanges(releaseId);
                });
            });
            
            // Update pagination
            updateReleasePagination(totalReleases);
        } catch (error) {
            console.error('Error loading releases:', error);
            releasesTableElement.innerHTML = '<tr><td colspan="6" class="text-center">Error loading releases</td></tr>';
        }
    }
    
    // Update Release Pagination
    function updateReleasePagination(totalReleases) {
        if (!releasesPaginationElement) return;
        
        if (totalReleases === 0) {
            releasesPaginationElement.style.display = 'none';
            return;
        }
        
        releasesPaginationElement.style.display = 'flex';
        
        let html = '';
        
        // Previous button
        html += `
            <div class="pagination-item ${currentReleasePage === 1 ? 'disabled' : ''}" data-page="prev">
                <i class="fas fa-chevron-left"></i>
            </div>
        `;
        
        // Page numbers
        const maxPages = Math.min(totalReleasePages, 5);
        let startPage = Math.max(1, currentReleasePage - 2);
        let endPage = Math.min(startPage + maxPages - 1, totalReleasePages);
        
        if (endPage - startPage < maxPages - 1) {
            startPage = Math.max(1, endPage - maxPages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <div class="pagination-item ${i === currentReleasePage ? 'active' : ''}" data-page="${i}">
                    ${i}
                </div>
            `;
        }
        
        // Next button
        html += `
            <div class="pagination-item ${currentReleasePage === totalReleasePages ? 'disabled' : ''}" data-page="next">
                <i class="fas fa-chevron-right"></i>
            </div>
        `;
        
        releasesPaginationElement.innerHTML = html;
        
        // Add event listeners for pagination
        const paginationItems = document.querySelectorAll('.pagination-item');
        paginationItems.forEach(item => {
            item.addEventListener('click', function() {
                if (this.classList.contains('disabled')) return;
                
                const page = this.dataset.page;
                
                if (page === 'prev') {
                    currentReleasePage = Math.max(1, currentReleasePage - 1);
                } else if (page === 'next') {
                    currentReleasePage = Math.min(totalReleasePages, currentReleasePage + 1);
                } else {
                    currentReleasePage = parseInt(page);
                }
                
                // Reload releases with current filter and search
                const filter = releaseStatusFilter ? releaseStatusFilter.value : 'all';
                const searchQuery = releaseSearchInput ? releaseSearchInput.value.trim() : '';
                
                loadReleases(filter, searchQuery);
            });
        });
    }
    
    // Initialize Release Filters
    function initializeReleaseFilters() {
        if (releaseStatusFilter) {
            releaseStatusFilter.addEventListener('change', function() {
                currentReleasePage = 1;
                const searchQuery = releaseSearchInput ? releaseSearchInput.value.trim() : '';
                loadReleases(this.value, searchQuery);
            });
        }
        
        if (releaseSearchBtn && releaseSearchInput) {
            releaseSearchBtn.addEventListener('click', function() {
                currentReleasePage = 1;
                const filter = releaseStatusFilter ? releaseStatusFilter.value : 'all';
                loadReleases(filter, releaseSearchInput.value.trim());
            });
            
            releaseSearchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    currentReleasePage = 1;
                    const filter = releaseStatusFilter ? releaseStatusFilter.value : 'all';
                    loadReleases(filter, this.value.trim());
                }
            });
        }
    }
    
    // View Release
    async function viewRelease(releaseId) {
        try {
            // Get release data
            const releaseDoc = await firebase.firestore().collection('releases').doc(releaseId).get();
            
            if (!releaseDoc.exists) {
                alert('Release not found.');
                return;
            }
            
            const releaseData = releaseDoc.data();
            
            // Format dates
            const createdAt = releaseData.createdAt ? new Date(releaseData.createdAt.toDate()) : new Date();
            const formattedCreatedDate = createdAt.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            const submittedAt = releaseData.submittedAt ? new Date(releaseData.submittedAt.toDate()) : null;
            const formattedSubmittedDate = submittedAt ? submittedAt.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            }) : 'Not submitted';
            
            // Get user data
            const userDoc = await firebase.firestore().collection('users').doc(releaseData.userId).get();
            const userData = userDoc.exists ? userDoc.data() : { name: 'Unknown User', email: 'No email' };
            
            // Get tracks
            const tracksSnapshot = await firebase.firestore().collection('releases')
                .doc(releaseId)
                .collection('tracks')
                .orderBy('trackNumber', 'asc')
                .get();
            
            let tracksHtml = '';
            
            if (tracksSnapshot.empty) {
                tracksHtml = '<p>No tracks found</p>';
            } else {
                tracksHtml = '<div class="tracks-list">';
                
                tracksSnapshot.forEach(doc => {
                    const trackData = doc.data();
                    
                    tracksHtml += `
                        <div class="track-item">
                            <div class="track-number">${trackData.trackNumber}</div>
                            <div class="track-info">
                                <div class="track-title">${trackData.title}</div>
                                <div class="track-artist">${trackData.artist}${trackData.featuring ? ` feat. ${trackData.featuring}` : ''}</div>
                            </div>
                            <div class="track-actions">
                                ${trackData.explicit ? '<span class="explicit-badge">E</span>' : ''}
                                <audio controls src="${trackData.trackURL}"></audio>
                            </div>
                        </div>
                    `;
                });
                
                tracksHtml += '</div>';
            }
            
            // Get DSPs
            let dspsHtml = '';
            
            if (releaseData.dsps && releaseData.dsps.length > 0) {
                // Get DSP data
                const dspsSnapshot = await firebase.firestore().collection('dsps')
                    .where(firebase.firestore.FieldPath.documentId(), 'in', releaseData.dsps)
                    .get();
                
                if (dspsSnapshot.empty) {
                    dspsHtml = '<p>No DSPs found</p>';
                } else {
                    dspsHtml = '<div class="dsp-grid">';
                    
                    dspsSnapshot.forEach(doc => {
                        const dspData = doc.data();
                        
                        dspsHtml += `
                            <div class="dsp-item">
                                <img src="${dspData.logoURL || '../assets/images/dsp-placeholder.png'}" alt="${dspData.name}">
                                <span>${dspData.name}</span>
                            </div>
                        `;
                    });
                    
                    dspsHtml += '</div>';
                }
            } else {
                dspsHtml = '<p>No DSPs selected</p>';
            }
            
            // Create modal content
            let modalContent = `
                <div class="release-details-modal">
                    <div class="release-details-header">
                        <div class="release-cover">
                            <img src="${releaseData.coverArtURL || '../assets/images/default-cover.jpg'}" alt="${releaseData.title}">
                        </div>
                        <div class="release-info">
                            <h2>${releaseData.title || 'Untitled Release'}</h2>
                            <div class="release-artist">${releaseData.primaryArtist || 'Unknown Artist'}</div>
                            <div class="release-meta">
                                <span>${releaseData.releaseType || 'Single'}</span>
                                <span class="status-badge ${getStatusBadgeClass(releaseData.status)}">${formatStatus(releaseData.status)}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="release-details-section">
                        <h3>Release Information</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">Release Date</div>
                                <div class="info-value">${releaseData.releaseDate || 'Not set'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Genre</div>
                                <div class="info-value">${releaseData.genre || 'Not specified'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Language</div>
                                <div class="info-value">${releaseData.language || 'Not specified'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">UPC</div>
                                <div class="info-value">${releaseData.upc || 'Not provided'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Created On</div>
                                <div class="info-value">${formattedCreatedDate}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Submitted On</div>
                                <div class="info-value">${formattedSubmittedDate}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="release-details-section">
                        <h3>Artist Information</h3>
                        <div class="artist-info">
                            <div class="user-avatar">
                                ${userData.name ? userData.name.charAt(0).toUpperCase() : 'U'}
                            </div>
                            <div>
                                <div class="artist-name">${userData.name || 'Unknown User'}</div>
                                <div class="artist-email">${userData.email || 'No email'}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="release-details-section">
                        <h3>Tracks</h3>
                        ${tracksHtml}
                    </div>
                    
                    <div class="release-details-section">
                        <h3>Distribution Platforms</h3>
                        ${dspsHtml}
                    </div>
                    
                    <div class="release-details-footer">
                        <button class="btn btn-primary close-modal">Close</button>
                        ${releaseData.status === 'in_review' ? `
                            <button class="btn btn-success approve-release-btn" data-id="${releaseId}">Approve</button>
                            <button class="btn btn-danger reject-release-btn" data-id="${releaseId}">Reject</button>
                            <button class="btn btn-warning request-changes-btn" data-id="${releaseId}">Request Changes</button>
                        ` : ''}
                    </div>
                </div>
            `;
            
            // Create modal
            const modalOverlay = document.createElement('div');
            modalOverlay.className = 'modal-overlay';
            modalOverlay.innerHTML = `
                <div class="modal-container large">
                    ${modalContent}
                </div>
            `;
            
            document.body.appendChild(modalOverlay);
            
            // Add event listeners for buttons
            const closeButton = modalOverlay.querySelector('.close-modal');
            closeButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
            });
            
            const approveButton = modalOverlay.querySelector('.approve-release-btn');
            if (approveButton) {
                approveButton.addEventListener('click', function() {
                    if (confirm('Are you sure you want to approve this release?')) {
                        document.body.removeChild(modalOverlay);
                        approveRelease(releaseId);
                    }
                });
            }
            
            const rejectButton = modalOverlay.querySelector('.reject-release-btn');
            if (rejectButton) {
                rejectButton.addEventListener('click', function() {
                    document.body.removeChild(modalOverlay);
                    rejectRelease(releaseId);
                });
            }
            
            const requestChangesButton = modalOverlay.querySelector('.request-changes-btn');
            if (requestChangesButton) {
                requestChangesButton.addEventListener('click', function() {
                    document.body.removeChild(modalOverlay);
                    requestChanges(releaseId);
                });
            }
            
            // Close modal when clicking outside
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    document.body.removeChild(modalOverlay);
                }
            });
        } catch (error) {
            console.error('Error viewing release:', error);
            alert('An error occurred while loading release details. Please try again.');
        }
    }
    
    // Approve Release
    async function approveRelease(releaseId) {
        try {
            // Update release status in Firestore
            await firebase.firestore().collection('releases').doc(releaseId).update({
                status: 'approved',
                isApproved: true,
                approvedBy: currentUser.uid,
                approvedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            
            // Reload releases
            loadReleases();
            
            alert('Release approved successfully!');
        } catch (error) {
            console.error('Error approving release:', error);
            alert('An error occurred while approving the release. Please try again.');
        }
    }
    
    // Reject Release
    function rejectRelease(releaseId) {
        // Create modal content
        let modalContent = `
            <div class="reject-release-modal">
                <div class="reject-release-header">
                    <h2>Reject Release</h2>
                </div>
                
                <div class="reject-release-form">
                    <div class="form-group">
                        <label for="rejectionReason">Reason for Rejection</label>
                        <textarea id="rejectionReason" class="form-control" rows="5" placeholder="Please provide a reason for rejecting this release..."></textarea>
                    </div>
                </div>
                
                <div class="reject-release-footer">
                    <button class="btn btn-secondary cancel-reject">Cancel</button>
                    <button class="btn btn-danger confirm-reject" data-id="${releaseId}">Reject Release</button>
                </div>
            </div>
        `;
        
        // Create modal
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'modal-overlay';
        modalOverlay.innerHTML = `
            <div class="modal-container">
                ${modalContent}
            </div>
        `;
        
        document.body.appendChild(modalOverlay);
        
        // Add event listeners for buttons
        const cancelButton = modalOverlay.querySelector('.cancel-reject');
        cancelButton.addEventListener('click', function() {
            document.body.removeChild(modalOverlay);
        });
        
        const confirmButton = modalOverlay.querySelector('.confirm-reject');
        confirmButton.addEventListener('click', async function() {
            const reason = document.getElementById('rejectionReason').value.trim();
            
            if (!reason) {
                alert('Please provide a reason for rejection.');
                return;
            }
            
            try {
                // Update release status in Firestore
                await firebase.firestore().collection('releases').doc(releaseId).update({
                    status: 'rejected',
                    isApproved: false,
                    rejectedBy: currentUser.uid,
                    rejectedAt: firebase.firestore.FieldValue.serverTimestamp(),
                    rejectionReason: reason
                });
                
                // Close modal
                document.body.removeChild(modalOverlay);
                
                // Reload releases
                loadReleases();
                
                alert('Release rejected successfully!');
            } catch (error) {
                console.error('Error rejecting release:', error);
                alert('An error occurred while rejecting the release. Please try again.');
            }
        });
        
        // Close modal when clicking outside
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) {
                document.body.removeChild(modalOverlay);
            }
        });
    }
    
    // Request Changes
    function requestChanges(releaseId) {
        // Create modal content
        let modalContent = `
            <div class="request-changes-modal">
                <div class="request-changes-header">
                    <h2>Request Changes</h2>
                </div>
                
                <div class="request-changes-form">
                    <div class="form-group">
                        <label for="requestedChanges">Requested Changes</label>
                        <textarea id="requestedChanges" class="form-control" rows="5" placeholder="Please specify the changes needed for this release..."></textarea>
                    </div>
                </div>
                
                <div class="request-changes-footer">
                    <button class="btn btn-secondary cancel-request">Cancel</button>
                    <button class="btn btn-warning confirm-request" data-id="${releaseId}">Request Changes</button>
                </div>
            </div>
        `;
        
        // Create modal
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'modal-overlay';
        modalOverlay.innerHTML = `
            <div class="modal-container">
                ${modalContent}
            </div>
        `;
        
        document.body.appendChild(modalOverlay);
        
        // Add event listeners for buttons
        const cancelButton = modalOverlay.querySelector('.cancel-request');
        cancelButton.addEventListener('click', function() {
            document.body.removeChild(modalOverlay);
        });
        
        const confirmButton = modalOverlay.querySelector('.confirm-request');
        confirmButton.addEventListener('click', async function() {
            const changes = document.getElementById('requestedChanges').value.trim();
            
            if (!changes) {
                alert('Please specify the changes needed.');
                return;
            }
            
            try {
                // Update release status in Firestore
                await firebase.firestore().collection('releases').doc(releaseId).update({
                    status: 'changes_requested',
                    requestedBy: currentUser.uid,
                    requestedAt: firebase.firestore.FieldValue.serverTimestamp(),
                    requestedChanges: changes
                });
                
                // Close modal
                document.body.removeChild(modalOverlay);
                
                // Reload releases
                loadReleases();
                
                alert('Changes requested successfully!');
            } catch (error) {
                console.error('Error requesting changes:', error);
                alert('An error occurred while requesting changes. Please try again.');
            }
        });
        
        // Close modal when clicking outside
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) {
                document.body.removeChild(modalOverlay);
            }
        });
    }
    
    // Load Royalty Data
    async function loadRoyaltyData() {
        // Implementation for royalty management in admin panel
        // This would be similar to the user royalty dashboard but with admin-specific features
    }
    
    // Load DSPs
    async function loadDSPs() {
        if (!dspsTableElement) return;
        
        try {
            // Show loading state
            dspsTableElement.innerHTML = '<tr><td colspan="5" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading DSPs...</td></tr>';
            
            // Get DSPs from Firestore
            const dspsSnapshot = await firebase.firestore().collection('dsps')
                .orderBy('name', 'asc')
                .get();
            
            if (dspsSnapshot.empty) {
                dspsTableElement.innerHTML = '<tr><td colspan="5" class="text-center">No DSPs found</td></tr>';
                return;
            }
            
            let html = '';
            
            dspsSnapshot.forEach(doc => {
                const dspData = doc.data();
                const dspId = doc.id;
                
                // Format date
                const createdAt = dspData.createdAt ? new Date(dspData.createdAt.toDate()) : new Date();
                const formattedDate = createdAt.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Get status badge class
                let statusBadgeClass = '';
                switch (dspData.status) {
                    case 'connected':
                        statusBadgeClass = 'approved';
                        break;
                    case 'disconnected':
                        statusBadgeClass = 'rejected';
                        break;
                    case 'pending':
                        statusBadgeClass = 'review';
                        break;
                    default:
                        statusBadgeClass = 'approved';
                }
                
                html += `
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center;">
                                <img src="${dspData.logoURL || '../assets/images/dsp-placeholder.png'}" alt="${dspData.name}" style="width: 40px; height: 40px; border-radius: 4px; margin-right: 10px;">
                                <div>
                                    <div style="font-weight: 600;">${dspData.name || 'Unknown DSP'}</div>
                                    <div style="font-size: 0.8rem; color: #666;">${dspData.apiEndpoint || 'No API endpoint'}</div>
                                </div>
                            </div>
                        </td>
                        <td><span class="status-badge ${statusBadgeClass}">${dspData.status || 'connected'}</span></td>
                        <td>${formattedDate}</td>
                        <td>${dspData.deliveryCount || 0}</td>
                        <td>
                            <div class="action-buttons">
                                <button class="action-btn view-dsp" data-id="${dspId}" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="action-btn edit-dsp" data-id="${dspId}" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                ${dspData.status === 'connected' ? `
                                    <button class="action-btn disconnect-dsp" data-id="${dspId}" title="Disconnect">
                                        <i class="fas fa-unlink"></i>
                                    </button>
                                ` : `
                                    <button class="action-btn connect-dsp" data-id="${dspId}" title="Connect">
                                        <i class="fas fa-link"></i>
                                    </button>
                                `}
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            dspsTableElement.innerHTML = html;
            
            // Add event listeners for action buttons
            const viewButtons = document.querySelectorAll('.view-dsp');
            viewButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const dspId = this.dataset.id;
                    viewDSP(dspId);
                });
            });
            
            const editButtons = document.querySelectorAll('.edit-dsp');
            editButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const dspId = this.dataset.id;
                    editDSP(dspId);
                });
            });
            
            const disconnectButtons = document.querySelectorAll('.disconnect-dsp');
            disconnectButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const dspId = this.dataset.id;
                    if (confirm('Are you sure you want to disconnect this DSP?')) {
                        updateDSPStatus(dspId, 'disconnected');
                    }
                });
            });
            
            const connectButtons = document.querySelectorAll('.connect-dsp');
            connectButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const dspId = this.dataset.id;
                    if (confirm('Are you sure you want to connect this DSP?')) {
                        updateDSPStatus(dspId, 'connected');
                    }
                });
            });
        } catch (error) {
            console.error('Error loading DSPs:', error);
            dspsTableElement.innerHTML = '<tr><td colspan="5" class="text-center">Error loading DSPs</td></tr>';
        }
    }
    
    // Initialize DSP Form
    function initializeDSPForm() {
        if (!dspForm) return;
        
        // Add event listener for form submission
        dspForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('dspName').value.trim();
            const apiEndpoint = document.getElementById('dspApiEndpoint').value.trim();
            const apiKey = document.getElementById('dspApiKey').value.trim();
            const apiSecret = document.getElementById('dspApiSecret').value.trim();
            
            // Validate form
            if (!name) {
                alert('Please enter a DSP name.');
                return;
            }
            
            if (!apiEndpoint) {
                alert('Please enter an API endpoint.');
                return;
            }
            
            // Show loading state
            const submitBtn = dspForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            
            try {
                // Check if we're editing or adding
                const isEditing = dspForm.dataset.editing === 'true';
                const editingId = dspForm.dataset.editingId;
                
                // Prepare DSP data
                const dspData = {
                    name: name,
                    apiEndpoint: apiEndpoint,
                    apiKey: apiKey,
                    apiSecret: apiSecret,
                    status: 'connected',
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                };
                
                if (isEditing) {
                    // Update existing DSP
                    await firebase.firestore().collection('dsps').doc(editingId).update(dspData);
                } else {
                    // Add new DSP
                    dspData.createdAt = firebase.firestore.FieldValue.serverTimestamp();
                    dspData.deliveryCount = 0;
                    
                    await firebase.firestore().collection('dsps').add(dspData);
                }
                
                // Reset form
                dspForm.reset();
                dspForm.dataset.editing = 'false';
                dspForm.dataset.editingId = '';
                
                // Update submit button
                submitBtn.textContent = 'Add DSP';
                
                // Reload DSPs
                loadDSPs();
                
                alert(`DSP ${isEditing ? 'updated' : 'added'} successfully!`);
            } catch (error) {
                console.error('Error saving DSP:', error);
                alert('An error occurred while saving the DSP. Please try again.');
            } finally {
                // Reset button
                submitBtn.disabled = false;
                submitBtn.textContent = originalBtnText;
            }
        });
        
        // Add event listener for add DSP button
        if (addDspBtn) {
            addDspBtn.addEventListener('click', function() {
                // Reset form
                dspForm.reset();
                dspForm.dataset.editing = 'false';
                dspForm.dataset.editingId = '';
                
                // Update submit button
                const submitBtn = dspForm.querySelector('button[type="submit"]');
                submitBtn.textContent = 'Add DSP';
                
                // Show form
                dspForm.style.display = 'block';
                
                // Scroll to form
                dspForm.scrollIntoView({ behavior: 'smooth' });
            });
        }
    }
    
    // View DSP
    async function viewDSP(dspId) {
        try {
            // Get DSP data
            const dspDoc = await firebase.firestore().collection('dsps').doc(dspId).get();
            
            if (!dspDoc.exists) {
                alert('DSP not found.');
                return;
            }
            
            const dspData = dspDoc.data();
            
            // Format date
            const createdAt = dspData.createdAt ? new Date(dspData.createdAt.toDate()) : new Date();
            const formattedDate = createdAt.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            // Create modal content
            let modalContent = `
                <div class="dsp-details-modal">
                    <div class="dsp-details-header">
                        <div class="dsp-logo">
                            <img src="${dspData.logoURL || '../assets/images/dsp-placeholder.png'}" alt="${dspData.name}">
                        </div>
                        <div class="dsp-info">
                            <h2>${dspData.name || 'Unknown DSP'}</h2>
                            <div class="dsp-meta">
                                <span class="status-badge ${dspData.status === 'connected' ? 'approved' : 'rejected'}">${dspData.status || 'connected'}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dsp-details-section">
                        <h3>API Information</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">API Endpoint</div>
                                <div class="info-value">${dspData.apiEndpoint || 'Not provided'}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">API Key</div>
                                <div class="info-value">
                                    <div class="masked-field">
                                        ${dspData.apiKey ? '••••••••••••••••' : 'Not provided'}
                                        ${dspData.apiKey ? '<button class="show-hide-btn" data-field="apiKey"><i class="fas fa-eye"></i></button>' : ''}
                                    </div>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">API Secret</div>
                                <div class="info-value">
                                    <div class="masked-field">
                                        ${dspData.apiSecret ? '••••••••••••••••' : 'Not provided'}
                                        ${dspData.apiSecret ? '<button class="show-hide-btn" data-field="apiSecret"><i class="fas fa-eye"></i></button>' : ''}
                                    </div>
                                </div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Created On</div>
                                <div class="info-value">${formattedDate}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dsp-details-section">
                        <h3>Delivery Statistics</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <div class="info-label">Total Deliveries</div>
                                <div class="info-value">${dspData.deliveryCount || 0}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Successful Deliveries</div>
                                <div class="info-value">${dspData.successfulDeliveries || 0}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Failed Deliveries</div>
                                <div class="info-value">${dspData.failedDeliveries || 0}</div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Pending Deliveries</div>
                                <div class="info-value">${dspData.pendingDeliveries || 0}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dsp-details-footer">
                        <button class="btn btn-primary close-modal">Close</button>
                        <button class="btn btn-secondary edit-dsp-btn" data-id="${dspId}">Edit DSP</button>
                        ${dspData.status === 'connected' ? `
                            <button class="btn btn-danger disconnect-dsp-btn" data-id="${dspId}">Disconnect DSP</button>
                        ` : `
                            <button class="btn btn-success connect-dsp-btn" data-id="${dspId}">Connect DSP</button>
                        `}
                    </div>
                </div>
            `;
            
            // Create modal
            const modalOverlay = document.createElement('div');
            modalOverlay.className = 'modal-overlay';
            modalOverlay.innerHTML = `
                <div class="modal-container">
                    ${modalContent}
                </div>
            `;
            
            document.body.appendChild(modalOverlay);
            
            // Add event listeners for buttons
            const closeButton = modalOverlay.querySelector('.close-modal');
            closeButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
            });
            
            const editButton = modalOverlay.querySelector('.edit-dsp-btn');
            editButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
                editDSP(dspId);
            });
            
            const disconnectButton = modalOverlay.querySelector('.disconnect-dsp-btn');
            if (disconnectButton) {
                disconnectButton.addEventListener('click', function() {
                    if (confirm('Are you sure you want to disconnect this DSP?')) {
                        document.body.removeChild(modalOverlay);
                        updateDSPStatus(dspId, 'disconnected');
                    }
                });
            }
            
            const connectButton = modalOverlay.querySelector('.connect-dsp-btn');
            if (connectButton) {
                connectButton.addEventListener('click', function() {
                    if (confirm('Are you sure you want to connect this DSP?')) {
                        document.body.removeChild(modalOverlay);
                        updateDSPStatus(dspId, 'connected');
                    }
                });
            }
            
            // Add event listeners for show/hide buttons
            const showHideButtons = modalOverlay.querySelectorAll('.show-hide-btn');
            showHideButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const field = this.dataset.field;
                    const maskedField = this.parentElement;
                    
                    if (this.classList.contains('showing')) {
                        // Hide the field
                        maskedField.innerHTML = `
                            ••••••••••••••••
                            <button class="show-hide-btn" data-field="${field}"><i class="fas fa-eye"></i></button>
                        `;
                    } else {
                        // Show the field
                        maskedField.innerHTML = `
                            ${dspData[field]}
                            <button class="show-hide-btn showing" data-field="${field}"><i class="fas fa-eye-slash"></i></button>
                        `;
                    }
                    
                    // Re-add event listener
                    maskedField.querySelector('.show-hide-btn').addEventListener('click', this.onclick);
                });
            });
            
            // Close modal when clicking outside
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    document.body.removeChild(modalOverlay);
                }
            });
        } catch (error) {
            console.error('Error viewing DSP:', error);
            alert('An error occurred while loading DSP details. Please try again.');
        }
    }
    
    // Edit DSP
    async function editDSP(dspId) {
        try {
            // Get DSP data
            const dspDoc = await firebase.firestore().collection('dsps').doc(dspId).get();
            
            if (!dspDoc.exists) {
                alert('DSP not found.');
                return;
            }
            
            const dspData = dspDoc.data();
            
            // Populate form
            document.getElementById('dspName').value = dspData.name || '';
            document.getElementById('dspApiEndpoint').value = dspData.apiEndpoint || '';
            document.getElementById('dspApiKey').value = dspData.apiKey || '';
            document.getElementById('dspApiSecret').value = dspData.apiSecret || '';
            
            // Set form to editing mode
            dspForm.dataset.editing = 'true';
            dspForm.dataset.editingId = dspId;
            
            // Update submit button
            const submitBtn = dspForm.querySelector('button[type="submit"]');
            submitBtn.textContent = 'Update DSP';
            
            // Show form
            dspForm.style.display = 'block';
            
            // Scroll to form
            dspForm.scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            console.error('Error editing DSP:', error);
            alert('An error occurred while loading DSP details. Please try again.');
        }
    }
    
    // Update DSP Status
    async function updateDSPStatus(dspId, status) {
        try {
            // Update DSP status in Firestore
            await firebase.firestore().collection('dsps').doc(dspId).update({
                status: status,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            
            // Reload DSPs
            loadDSPs();
            
            alert(`DSP ${status === 'connected' ? 'connected' : 'disconnected'} successfully!`);
        } catch (error) {
            console.error('Error updating DSP status:', error);
            alert('An error occurred while updating the DSP status. Please try again.');
        }
    }
    
    // Helper Functions
    function formatStatus(status) {
        switch (status) {
            case 'draft':
                return 'Draft';
            case 'in_review':
                return 'In Review';
            case 'approved':
                return 'Approved';
            case 'rejected':
                return 'Rejected';
            case 'changes_requested':
                return 'Changes Requested';
            case 'live':
                return 'Live';
            default:
                return 'Draft';
        }
    }
    
    function getStatusBadgeClass(status) {
        switch (status) {
            case 'draft':
                return 'draft';
            case 'in_review':
                return 'review';
            case 'approved':
                return 'approved';
            case 'rejected':
                return 'rejected';
            case 'changes_requested':
                return 'changes';
            default:
                return 'draft';
        }
    }
    
    function formatCurrency(amount, abbreviated = false) {
        if (abbreviated) {
            if (amount >= 1000000) {
                return '₹' + (amount / 1000000).toFixed(1) + 'M';
            }
            if (amount >= 1000) {
                return '₹' + (amount / 1000).toFixed(1) + 'K';
            }
            return '₹' + amount.toFixed(2);
        }
        
        return new Intl.NumberFormat('en-IN', { 
            style: 'currency', 
            currency: 'INR',
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    function formatNumber(num, abbreviated = false) {
        if (abbreviated) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            }
            return num.toString();
        }
        
        return new Intl.NumberFormat().format(num);
    }
    
    // Get Document at Index
    async function getDocAtIndex(query, index) {
        const snapshot = await query.limit(index + 1).get();
        return snapshot.docs[index];
    }
});
