// Collaborator management functionality for Sangeet Distribution
document.addEventListener('DOMContentLoaded', function() {
    // Import Firebase configuration
    // Firebase config is loaded in the main HTML file
    
    // DOM Elements - Collaborator Management
    const collaboratorForm = document.getElementById('collaboratorForm');
    const collaboratorName = document.getElementById('collaboratorName');
    const collaboratorEmail = document.getElementById('collaboratorEmail');
    const collaboratorRole = document.getElementById('collaboratorRole');
    const collaboratorShare = document.getElementById('collaboratorShare');
    const collaboratorError = document.getElementById('collaboratorError');
    const collaboratorsList = document.getElementById('collaboratorsList');
    const totalShareElement = document.getElementById('totalShare');
    const remainingShareElement = document.getElementById('remainingShare');
    
    // DOM Elements - Release Selection
    const releaseSelectElement = document.getElementById('releaseSelect');
    
    // Variables
    let currentUser = null;
    let currentReleaseId = null;
    let collaborators = [];
    let totalShare = 0;
    const maxShare = 100;
    
    // Check authentication state
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            // User is signed in
            currentUser = user;
            
            // Load releases for dropdown
            loadReleases();
            
            // Initialize form submission
            if (collaboratorForm) {
                collaboratorForm.addEventListener('submit', handleCollaboratorSubmission);
            }
            
            // Check if we have a release ID in URL
            const urlParams = new URLSearchParams(window.location.search);
            const releaseId = urlParams.get('id');
            
            if (releaseId) {
                currentReleaseId = releaseId;
                
                // Set release in dropdown
                if (releaseSelectElement) {
                    // Wait for releases to load
                    setTimeout(() => {
                        releaseSelectElement.value = releaseId;
                        loadCollaborators(releaseId);
                    }, 1000);
                } else {
                    // Load collaborators directly
                    loadCollaborators(releaseId);
                }
            }
        }
    });
    
    // Load Releases
    async function loadReleases() {
        if (!releaseSelectElement) return;
        
        try {
            // Get releases from Firestore
            const releasesSnapshot = await firebase.firestore().collection('releases')
                .where('userId', '==', currentUser.uid)
                .orderBy('createdAt', 'desc')
                .get();
            
            if (releasesSnapshot.empty) {
                releaseSelectElement.innerHTML = '<option value="">No releases found</option>';
                releaseSelectElement.disabled = true;
                return;
            }
            
            let html = '<option value="">Select a release</option>';
            
            releasesSnapshot.forEach(doc => {
                const releaseData = doc.data();
                html += `<option value="${doc.id}">${releaseData.title || 'Untitled Release'} - ${releaseData.primaryArtist || 'Unknown Artist'}</option>`;
            });
            
            releaseSelectElement.innerHTML = html;
            releaseSelectElement.disabled = false;
            
            // Add event listener for release select
            releaseSelectElement.addEventListener('change', function() {
                currentReleaseId = this.value;
                
                if (currentReleaseId) {
                    loadCollaborators(currentReleaseId);
                    
                    // Update URL
                    const url = new URL(window.location);
                    url.searchParams.set('id', currentReleaseId);
                    window.history.pushState({}, '', url);
                } else {
                    // Clear collaborators
                    if (collaboratorsList) {
                        collaboratorsList.innerHTML = '<tr><td colspan="5" class="text-center">Please select a release</td></tr>';
                    }
                    
                    // Reset share counters
                    updateShareCounters(0);
                    
                    // Reset URL
                    const url = new URL(window.location);
                    url.searchParams.delete('id');
                    window.history.pushState({}, '', url);
                }
            });
        } catch (error) {
            console.error('Error loading releases:', error);
            releaseSelectElement.innerHTML = '<option value="">Error loading releases</option>';
            releaseSelectElement.disabled = true;
        }
    }
    
    // Load Collaborators
    async function loadCollaborators(releaseId) {
        if (!collaboratorsList) return;
        
        try {
            // Show loading state
            collaboratorsList.innerHTML = '<tr><td colspan="5" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading collaborators...</td></tr>';
            
            // Get release data
            const releaseDoc = await firebase.firestore().collection('releases').doc(releaseId).get();
            
            if (!releaseDoc.exists) {
                collaboratorsList.innerHTML = '<tr><td colspan="5" class="text-center">Release not found</td></tr>';
                return;
            }
            
            const releaseData = releaseDoc.data();
            
            // Check if user owns this release
            if (releaseData.userId !== currentUser.uid) {
                collaboratorsList.innerHTML = '<tr><td colspan="5" class="text-center">You do not have permission to view this release</td></tr>';
                return;
            }
            
            // Get collaborators
            const collaboratorsSnapshot = await firebase.firestore().collection('releases')
                .doc(releaseId)
                .collection('collaborators')
                .get();
            
            if (collaboratorsSnapshot.empty) {
                // Add primary artist as default collaborator
                collaborators = [{
                    id: 'primary',
                    name: releaseData.primaryArtist || 'Primary Artist',
                    role: 'Primary Artist',
                    share: 100,
                    isPrimary: true
                }];
            } else {
                // Get collaborators from snapshot
                collaborators = [];
                let hasPrimary = false;
                
                collaboratorsSnapshot.forEach(doc => {
                    const collaboratorData = doc.data();
                    
                    if (collaboratorData.isPrimary) {
                        hasPrimary = true;
                    }
                    
                    collaborators.push({
                        id: doc.id,
                        name: collaboratorData.name || 'Unknown',
                        email: collaboratorData.email || null,
                        role: collaboratorData.role || 'Collaborator',
                        share: collaboratorData.share || 0,
                        isPrimary: collaboratorData.isPrimary || false
                    });
                });
                
                // Add primary artist if not present
                if (!hasPrimary) {
                    collaborators.unshift({
                        id: 'primary',
                        name: releaseData.primaryArtist || 'Primary Artist',
                        role: 'Primary Artist',
                        share: 100 - collaborators.reduce((total, collab) => total + collab.share, 0),
                        isPrimary: true
                    });
                }
            }
            
            // Update collaborators list
            updateCollaboratorsList();
            
            // Calculate total share
            totalShare = collaborators.reduce((total, collab) => total + collab.share, 0);
            
            // Update share counters
            updateShareCounters(totalShare);
        } catch (error) {
            console.error('Error loading collaborators:', error);
            collaboratorsList.innerHTML = '<tr><td colspan="5" class="text-center">Error loading collaborators</td></tr>';
        }
    }
    
    // Update Collaborators List
    function updateCollaboratorsList() {
        if (!collaboratorsList) return;
        
        if (collaborators.length === 0) {
            collaboratorsList.innerHTML = '<tr><td colspan="5" class="text-center">No collaborators found</td></tr>';
            return;
        }
        
        let html = '';
        
        collaborators.forEach(collaborator => {
            html += `
                <tr>
                    <td>${collaborator.name}</td>
                    <td>${collaborator.email || 'N/A'}</td>
                    <td>${collaborator.role}</td>
                    <td>
                        <div class="share-container">
                            <div class="share-bar" style="width: ${collaborator.share}%;"></div>
                            <span>${collaborator.share}%</span>
                        </div>
                    </td>
                    <td>
                        <div class="action-buttons">
                            ${!collaborator.isPrimary ? `
                                <button class="action-btn edit-collaborator" data-id="${collaborator.id}" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="action-btn delete-collaborator" data-id="${collaborator.id}" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            ` : '<span class="primary-badge">Primary</span>'}
                        </div>
                    </td>
                </tr>
            `;
        });
        
        collaboratorsList.innerHTML = html;
        
        // Add event listeners for edit buttons
        const editButtons = document.querySelectorAll('.edit-collaborator');
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const collaboratorId = this.dataset.id;
                editCollaborator(collaboratorId);
            });
        });
        
        // Add event listeners for delete buttons
        const deleteButtons = document.querySelectorAll('.delete-collaborator');
        deleteButtons.forEach(button => {
            button.addEventListener('click', function() {
                const collaboratorId = this.dataset.id;
                if (confirm('Are you sure you want to delete this collaborator?')) {
                    deleteCollaborator(collaboratorId);
                }
            });
        });
    }
    
    // Update Share Counters
    function updateShareCounters(total) {
        if (totalShareElement) {
            totalShareElement.textContent = `${total}%`;
            
            // Add warning class if total is not 100%
            if (total !== 100) {
                totalShareElement.classList.add('warning');
            } else {
                totalShareElement.classList.remove('warning');
            }
        }
        
        if (remainingShareElement) {
            const remaining = maxShare - total;
            remainingShareElement.textContent = `${remaining}%`;
            
            // Add warning class if remaining is negative
            if (remaining < 0) {
                remainingShareElement.classList.add('warning');
            } else {
                remainingShareElement.classList.remove('warning');
            }
        }
    }
    
    // Handle Collaborator Submission
    async function handleCollaboratorSubmission(e) {
        e.preventDefault();
        
        // Clear previous errors
        if (collaboratorError) collaboratorError.textContent = '';
        
        // Check if release is selected
        if (!currentReleaseId) {
            if (collaboratorError) collaboratorError.textContent = 'Please select a release.';
            return;
        }
        
        // Get form values
        const name = collaboratorName.value.trim();
        const email = collaboratorEmail.value.trim();
        const role = collaboratorRole.value.trim();
        const share = parseInt(collaboratorShare.value) || 0;
        
        // Validate form
        if (!name) {
            if (collaboratorError) collaboratorError.textContent = 'Please enter a name.';
            collaboratorName.focus();
            return;
        }
        
        if (share <= 0) {
            if (collaboratorError) collaboratorError.textContent = 'Please enter a valid share percentage.';
            collaboratorShare.focus();
            return;
        }
        
        // Check if we're editing or adding
        const isEditing = collaboratorForm.dataset.editing === 'true';
        const editingId = collaboratorForm.dataset.editingId;
        
        // Calculate new total share
        let newTotalShare = totalShare;
        
        if (isEditing) {
            // Subtract existing share
            const existingCollaborator = collaborators.find(c => c.id === editingId);
            if (existingCollaborator) {
                newTotalShare -= existingCollaborator.share;
            }
        }
        
        newTotalShare += share;
        
        // Check if total share exceeds 100%
        if (newTotalShare > maxShare) {
            if (collaboratorError) collaboratorError.textContent = `Total share cannot exceed ${maxShare}%. Please reduce the share percentage.`;
            collaboratorShare.focus();
            return;
        }
        
        // Show loading state
        const submitBtn = collaboratorForm.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        
        try {
            // Prepare collaborator data
            const collaboratorData = {
                name: name,
                email: email || null,
                role: role,
                share: share,
                isPrimary: false,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            };
            
            if (isEditing) {
                // Update existing collaborator
                await firebase.firestore().collection('releases')
                    .doc(currentReleaseId)
                    .collection('collaborators')
                    .doc(editingId)
                    .update(collaboratorData);
                
                // Update primary artist's share
                const primaryCollaborator = collaborators.find(c => c.isPrimary);
                if (primaryCollaborator && primaryCollaborator.id !== editingId) {
                    const primaryShare = maxShare - (newTotalShare - share);
                    
                    if (primaryCollaborator.id === 'primary') {
                        // Primary artist is not in the collaborators collection
                        // Just update the local array
                        primaryCollaborator.share = primaryShare;
                    } else {
                        // Update primary artist in Firestore
                        await firebase.firestore().collection('releases')
                            .doc(currentReleaseId)
                            .collection('collaborators')
                            .doc(primaryCollaborator.id)
                            .update({
                                share: primaryShare,
                                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                            });
                    }
                }
            } else {
                // Add new collaborator
                await firebase.firestore().collection('releases')
                    .doc(currentReleaseId)
                    .collection('collaborators')
                    .add({
                        ...collaboratorData,
                        createdAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                
                // Update primary artist's share
                const primaryCollaborator = collaborators.find(c => c.isPrimary);
                if (primaryCollaborator) {
                    const primaryShare = maxShare - (newTotalShare - share);
                    
                    if (primaryCollaborator.id === 'primary') {
                        // Primary artist is not in the collaborators collection
                        // Just update the local array
                        primaryCollaborator.share = primaryShare;
                    } else {
                        // Update primary artist in Firestore
                        await firebase.firestore().collection('releases')
                            .doc(currentReleaseId)
                            .collection('collaborators')
                            .doc(primaryCollaborator.id)
                            .update({
                                share: primaryShare,
                                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                            });
                    }
                }
            }
            
            // Reset form
            collaboratorForm.reset();
            collaboratorForm.dataset.editing = 'false';
            collaboratorForm.dataset.editingId = '';
            
            // Update submit button
            submitBtn.textContent = 'Add Collaborator';
            
            // Reload collaborators
            loadCollaborators(currentReleaseId);
        } catch (error) {
            console.error('Error saving collaborator:', error);
            if (collaboratorError) collaboratorError.textContent = 'An error occurred while saving. Please try again.';
        } finally {
            // Reset button
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }
    }
    
    // Edit Collaborator
    function editCollaborator(collaboratorId) {
        const collaborator = collaborators.find(c => c.id === collaboratorId);
        
        if (!collaborator) return;
        
        // Populate form
        collaboratorName.value = collaborator.name || '';
        collaboratorEmail.value = collaborator.email || '';
        collaboratorRole.value = collaborator.role || '';
        collaboratorShare.value = collaborator.share || 0;
        
        // Set form to editing mode
        collaboratorForm.dataset.editing = 'true';
        collaboratorForm.dataset.editingId = collaboratorId;
        
        // Update submit button
        const submitBtn = collaboratorForm.querySelector('button[type="submit"]');
        submitBtn.textContent = 'Update Collaborator';
        
        // Scroll to form
        collaboratorForm.scrollIntoView({ behavior: 'smooth' });
    }
    
    // Delete Collaborator
    async function deleteCollaborator(collaboratorId) {
        try {
            // Delete collaborator from Firestore
            await firebase.firestore().collection('releases')
                .doc(currentReleaseId)
                .collection('collaborators')
                .doc(collaboratorId)
                .delete();
            
            // Get collaborator share
            const collaborator = collaborators.find(c => c.id === collaboratorId);
            const deletedShare = collaborator ? collaborator.share : 0;
            
            // Update primary artist's share
            const primaryCollaborator = collaborators.find(c => c.isPrimary);
            if (primaryCollaborator) {
                const primaryShare = primaryCollaborator.share + deletedShare;
                
                if (primaryCollaborator.id === 'primary') {
                    // Primary artist is not in the collaborators collection
                    // Just update the local array
                    primaryCollaborator.share = primaryShare;
                } else {
                    // Update primary artist in Firestore
                    await firebase.firestore().collection('releases')
                        .doc(currentReleaseId)
                        .collection('collaborators')
                        .doc(primaryCollaborator.id)
                        .update({
                            share: primaryShare,
                            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                        });
                }
            }
            
            // Reload collaborators
            loadCollaborators(currentReleaseId);
        } catch (error) {
            console.error('Error deleting collaborator:', error);
            alert('An error occurred while deleting the collaborator. Please try again.');
        }
    }
});
