// Dashboard functionality for Sangeet Distribution
document.addEventListener('DOMContentLoaded', function() {
    // Import Firebase configuration
    // Firebase config is loaded in the main HTML file
    
    // DOM Elements - Dashboard
    const userNameElement = document.getElementById('userName');
    const userAvatarElement = document.getElementById('userAvatar');
    const totalReleasesElement = document.getElementById('totalReleases');
    const totalStreamsElement = document.getElementById('totalStreams');
    const totalEarningsElement = document.getElementById('totalEarnings');
    const pendingReleasesElement = document.getElementById('pendingReleases');
    
    // DOM Elements - Charts
    const earningsChartElement = document.getElementById('earningsChart');
    const streamsChartElement = document.getElementById('streamsChart');
    const dspBreakdownChartElement = document.getElementById('dspBreakdownChart');
    
    // DOM Elements - Release List
    const recentReleasesListElement = document.getElementById('recentReleasesList');
    
    // Check authentication state
    firebase.auth().onAuthStateChanged(async function(user) {
        if (user) {
            // User is signed in
            try {
                // Get user data from Firestore
                const userDoc = await firebase.firestore().collection('users').doc(user.uid).get();
                
                if (userDoc.exists) {
                    const userData = userDoc.data();
                    
                    // Update user info in UI
                    if (userNameElement) {
                        userNameElement.textContent = userData.name || user.displayName || 'User';
                    }
                    
                    if (userAvatarElement) {
                        if (userData.photoURL || user.photoURL) {
                            userAvatarElement.src = userData.photoURL || user.photoURL;
                        }
                    }
                    
                    // Load dashboard data
                    loadDashboardData(user.uid);
                    
                    // Initialize charts
                    initializeCharts(user.uid);
                    
                    // Load recent releases
                    loadRecentReleases(user.uid);
                }
            } catch (error) {
                console.error('Error loading user data:', error);
            }
        }
    });
    
    // Load dashboard data
    async function loadDashboardData(userId) {
        try {
            // Get releases count
            const releasesSnapshot = await firebase.firestore().collection('releases')
                .where('userId', '==', userId)
                .get();
            
            const totalReleases = releasesSnapshot.size;
            
            if (totalReleasesElement) {
                totalReleasesElement.textContent = totalReleases;
            }
            
            // Get pending releases count
            const pendingReleasesSnapshot = await firebase.firestore().collection('releases')
                .where('userId', '==', userId)
                .where('status', 'in', ['draft', 'in_review', 'changes_requested'])
                .get();
            
            const pendingReleases = pendingReleasesSnapshot.size;
            
            if (pendingReleasesElement) {
                pendingReleasesElement.textContent = pendingReleases;
            }
            
            // Get royalty data
            const royaltiesSnapshot = await firebase.firestore().collection('royalties')
                .where('userId', '==', userId)
                .orderBy('period', 'desc')
                .limit(12)
                .get();
            
            let totalStreams = 0;
            let totalEarnings = 0;
            
            royaltiesSnapshot.forEach(doc => {
                const royaltyData = doc.data();
                totalStreams += royaltyData.streams || 0;
                totalEarnings += royaltyData.amount || 0;
            });
            
            if (totalStreamsElement) {
                totalStreamsElement.textContent = formatNumber(totalStreams);
            }
            
            if (totalEarningsElement) {
                totalEarningsElement.textContent = formatCurrency(totalEarnings);
            }
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        }
    }
    
    // Initialize charts
    async function initializeCharts(userId) {
        try {
            // Get royalty data for charts
            const royaltiesSnapshot = await firebase.firestore().collection('royalties')
                .where('userId', '==', userId)
                .orderBy('period', 'asc')
                .limit(12)
                .get();
            
            const periods = [];
            const earnings = [];
            const streams = [];
            const dspData = {};
            
            royaltiesSnapshot.forEach(doc => {
                const royaltyData = doc.data();
                
                // Format period (YYYY-MM) to MMM YYYY
                const year = royaltyData.period.substring(0, 4);
                const month = royaltyData.period.substring(5, 7);
                const date = new Date(year, month - 1);
                const formattedPeriod = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                
                periods.push(formattedPeriod);
                earnings.push(royaltyData.amount || 0);
                streams.push(royaltyData.streams || 0);
                
                // Aggregate DSP data
                if (royaltyData.dspBreakdown) {
                    Object.keys(royaltyData.dspBreakdown).forEach(dsp => {
                        if (!dspData[dsp]) {
                            dspData[dsp] = 0;
                        }
                        dspData[dsp] += royaltyData.dspBreakdown[dsp].amount || 0;
                    });
                }
            });
            
            // Create earnings chart
            if (earningsChartElement) {
                const earningsCtx = earningsChartElement.getContext('2d');
                new Chart(earningsCtx, {
                    type: 'line',
                    data: {
                        labels: periods,
                        datasets: [{
                            label: 'Earnings',
                            data: earnings,
                            backgroundColor: 'rgba(138, 79, 255, 0.1)',
                            borderColor: 'rgba(138, 79, 255, 1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return formatCurrency(context.raw);
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return formatCurrency(value, true);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            // Create streams chart
            if (streamsChartElement) {
                const streamsCtx = streamsChartElement.getContext('2d');
                new Chart(streamsCtx, {
                    type: 'bar',
                    data: {
                        labels: periods,
                        datasets: [{
                            label: 'Streams',
                            data: streams,
                            backgroundColor: 'rgba(0, 168, 225, 0.7)',
                            borderWidth: 0,
                            borderRadius: 5
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return formatNumber(context.raw) + ' streams';
                                    }
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value) {
                                        return formatNumber(value, true);
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            // Create DSP breakdown chart
            if (dspBreakdownChartElement) {
                const dspLabels = Object.keys(dspData);
                const dspValues = Object.values(dspData);
                const dspColors = getDspColors(dspLabels);
                
                const dspBreakdownCtx = dspBreakdownChartElement.getContext('2d');
                new Chart(dspBreakdownCtx, {
                    type: 'doughnut',
                    data: {
                        labels: dspLabels,
                        datasets: [{
                            data: dspValues,
                            backgroundColor: dspColors,
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'right'
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.raw;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: ${formatCurrency(value)} (${percentage}%)`;
                                    }
                                }
                            }
                        },
                        cutout: '70%'
                    }
                });
            }
        } catch (error) {
            console.error('Error initializing charts:', error);
        }
    }
    
    // Load recent releases
    async function loadRecentReleases(userId) {
        try {
            if (!recentReleasesListElement) return;
            
            // Get recent releases
            const releasesSnapshot = await firebase.firestore().collection('releases')
                .where('userId', '==', userId)
                .orderBy('createdAt', 'desc')
                .limit(5)
                .get();
            
            if (releasesSnapshot.empty) {
                recentReleasesListElement.innerHTML = '<tr><td colspan="5" class="text-center">No releases found</td></tr>';
                return;
            }
            
            let html = '';
            
            releasesSnapshot.forEach(doc => {
                const releaseData = doc.data();
                const releaseId = doc.id;
                
                // Format date
                const createdAt = releaseData.createdAt ? new Date(releaseData.createdAt.toDate()) : new Date();
                const formattedDate = createdAt.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Get status badge class
                let statusBadgeClass = '';
                switch (releaseData.status) {
                    case 'draft':
                        statusBadgeClass = 'draft';
                        break;
                    case 'in_review':
                        statusBadgeClass = 'review';
                        break;
                    case 'approved':
                        statusBadgeClass = 'approved';
                        break;
                    case 'rejected':
                        statusBadgeClass = 'rejected';
                        break;
                    case 'changes_requested':
                        statusBadgeClass = 'changes';
                        break;
                    default:
                        statusBadgeClass = 'draft';
                }
                
                html += `
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center;">
                                <img src="${releaseData.coverArtURL || '../assets/images/default-cover.jpg'}" alt="${releaseData.title}" style="width: 40px; height: 40px; border-radius: 4px; margin-right: 10px;">
                                <div>
                                    <div style="font-weight: 600;">${releaseData.title || 'Untitled Release'}</div>
                                    <div style="font-size: 0.8rem; color: #666;">${releaseData.primaryArtist || 'Unknown Artist'}</div>
                                </div>
                            </div>
                        </td>
                        <td>${releaseData.releaseType || 'Single'}</td>
                        <td>${formattedDate}</td>
                        <td><span class="status-badge ${statusBadgeClass}">${formatStatus(releaseData.status)}</span></td>
                        <td>
                            <div class="action-buttons">
                                <a href="release-details.html?id=${releaseId}" class="action-btn" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="upload.html?id=${releaseId}" class="action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            recentReleasesListElement.innerHTML = html;
        } catch (error) {
            console.error('Error loading recent releases:', error);
            if (recentReleasesListElement) {
                recentReleasesListElement.innerHTML = '<tr><td colspan="5" class="text-center">Error loading releases</td></tr>';
            }
        }
    }
    
    // Helper Functions
    function formatNumber(num, abbreviated = false) {
        if (abbreviated) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            }
            return num.toString();
        }
        
        return new Intl.NumberFormat().format(num);
    }
    
    function formatCurrency(amount, abbreviated = false) {
        if (abbreviated) {
            if (amount >= 1000000) {
                return '₹' + (amount / 1000000).toFixed(1) + 'M';
            }
            if (amount >= 1000) {
                return '₹' + (amount / 1000).toFixed(1) + 'K';
            }
            return '₹' + amount.toFixed(2);
        }
        
        return new Intl.NumberFormat('en-IN', { 
            style: 'currency', 
            currency: 'INR',
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    function formatStatus(status) {
        switch (status) {
            case 'draft':
                return 'Draft';
            case 'in_review':
                return 'In Review';
            case 'approved':
                return 'Approved';
            case 'rejected':
                return 'Rejected';
            case 'changes_requested':
                return 'Changes Requested';
            case 'live':
                return 'Live';
            default:
                return 'Draft';
        }
    }
    
    function getDspColors(dsps) {
        const colorMap = {
            'spotify': '#1DB954',
            'apple': '#FC3C44',
            'youtube': '#FF0000',
            'amazon': '#00A8E1',
            'jiosaavn': '#2BC5B4',
            'gaana': '#E72C30',
            'wynk': '#FF5722',
            'resso': '#00C2FF'
        };
        
        return dsps.map(dsp => {
            const lowerDsp = dsp.toLowerCase();
            
            for (const [key, color] of Object.entries(colorMap)) {
                if (lowerDsp.includes(key)) {
                    return color;
                }
            }
            
            // Default color if no match
            return '#' + Math.floor(Math.random() * 16777215).toString(16);
        });
    }
});
