// Sangeet Distribution - Main JavaScript

// DOM Elements
document.addEventListener('DOMContentLoaded', function() {
    // Header scroll effect
    const header = document.querySelector('.header');
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    const authButtons = document.querySelector('.auth-buttons');
    
    // Pricing toggle
    const pricingToggle = document.getElementById('pricing-toggle');
    const basicPrice = document.getElementById('basic-price');
    const proPrice = document.getElementById('pro-price');
    const premiumPrice = document.getElementById('premium-price');
    
    // Testimonial slider
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    const dots = document.querySelectorAll('.dot');
    
    // Scroll event for header
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    // Mobile menu toggle
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            authButtons.classList.toggle('active');
            
            // Toggle menu icon
            const icon = mobileMenuBtn.querySelector('i');
            if (icon.classList.contains('fa-bars')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }
    
    // Pricing toggle functionality
    if (pricingToggle) {
        pricingToggle.addEventListener('change', function() {
            if (this.checked) {
                // Yearly pricing (with 20% discount)
                basicPrice.innerHTML = '₹999<span>/year</span>';
                proPrice.innerHTML = '₹2,499<span>/year</span>';
                premiumPrice.innerHTML = '₹4,999<span>/year</span>';
            } else {
                // Monthly pricing
                basicPrice.innerHTML = '₹99<span>/month</span>';
                proPrice.innerHTML = '₹249<span>/month</span>';
                premiumPrice.innerHTML = '₹499<span>/month</span>';
            }
        });
    }
    
    // Testimonial slider functionality
    let currentSlide = 0;
    
    function showSlide(index) {
        testimonialCards.forEach(card => card.style.display = 'none');
        dots.forEach(dot => dot.classList.remove('active'));
        
        testimonialCards[index].style.display = 'block';
        dots[index].classList.add('active');
        currentSlide = index;
    }
    
    // Initialize slider
    if (testimonialCards.length > 0) {
        showSlide(0);
        
        // Add click event to dots
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                showSlide(index);
            });
        });
        
        // Auto slide every 5 seconds
        setInterval(() => {
            let nextSlide = currentSlide + 1;
            if (nextSlide >= testimonialCards.length) {
                nextSlide = 0;
            }
            showSlide(nextSlide);
        }, 5000);
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Animation on scroll
    const animateElements = document.querySelectorAll('.animate-fade-in');
    
    function checkIfInView() {
        animateElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.classList.add('visible');
            }
        });
    }
    
    window.addEventListener('scroll', checkIfInView);
    checkIfInView(); // Check on page load
});

// Firebase Configuration and Initialization
function initializeFirebase() {
    // Firebase configuration
    const firebaseConfig = {
        apiKey: "AIzaSyBWTDw2mJvbtO6hGU0dVwFYl0zQA2ESbiA",
        authDomain: "sangeet-distribution-1-f3aa0.firebaseapp.com",
        projectId: "sangeet-distribution-1-f3aa0",
        storageBucket: "sangeet-distribution-1-f3aa0.firebasestorage.app",
        messagingSenderId: "426232973667",
        appId: "1:426232973667:web:d7599348df3ab66be4eb56",
        measurementId: "G-GQMW91PYK3"
    };
    
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);
    firebase.analytics();
    
    console.log("Firebase initialized successfully");
    
    // Initialize Firebase services
    const auth = firebase.auth();
    const db = firebase.firestore();
    const storage = firebase.storage();
    
    return { auth, db, storage };
}

// Call initializeFirebase when Firebase scripts are loaded
// This will be used in dashboard and admin pages
window.onFirebaseReady = function() {
    const { auth, db, storage } = initializeFirebase();
    
    // Make Firebase services available globally
    window.firebaseAuth = auth;
    window.firebaseDb = db;
    window.firebaseStorage = storage;
    
    // Check authentication state
    auth.onAuthStateChanged(user => {
        if (user) {
            console.log("User is signed in:", user.email);
            // Handle signed-in user
        } else {
            console.log("No user is signed in");
            // Handle signed-out state
        }
    });
};
