// Firebase Configuration for Sangeet Distribution
const firebaseConfig = {
  apiKey: "AIzaSyBWTDw2mJvbtO6hGU0dVwFYl0zQA2ESbiA",
  authDomain: "sangeet-distribution-1-f3aa0.firebaseapp.com",
  projectId: "sangeet-distribution-1-f3aa0",
  storageBucket: "sangeet-distribution-1-f3aa0.firebasestorage.app",
  messagingSenderId: "426232973667",
  appId: "1:426232973667:web:d7599348df3ab66be4eb56",
  measurementId: "G-GQMW91PYK3"
};

// Initialize Firebase
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
}

// Firebase services
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();
const functions = firebase.functions();

// Authentication helper functions
const createUser = async (email, password, userData) => {
  try {
    // Create user with email and password
    const userCredential = await auth.createUserWithEmailAndPassword(email, password);
    const user = userCredential.user;
    
    // Add user data to Firestore
    await db.collection('users').doc(user.uid).set({
      ...userData,
      email: email,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      role: 'artist', // Default role
      isVerified: false,
      status: 'active'
    });
    
    // Update user profile
    await user.updateProfile({
      displayName: userData.name
    });
    
    return { success: true, user };
  } catch (error) {
    console.error("Error creating user:", error);
    return { success: false, error };
  }
};

const loginUser = async (email, password) => {
  try {
    const userCredential = await auth.signInWithEmailAndPassword(email, password);
    return { success: true, user: userCredential.user };
  } catch (error) {
    console.error("Error logging in:", error);
    return { success: false, error };
  }
};

const logoutUser = async () => {
  try {
    await auth.signOut();
    return { success: true };
  } catch (error) {
    console.error("Error logging out:", error);
    return { success: false, error };
  }
};

const resetPassword = async (email) => {
  try {
    await auth.sendPasswordResetEmail(email);
    return { success: true };
  } catch (error) {
    console.error("Error resetting password:", error);
    return { success: false, error };
  }
};

// Firestore helper functions
const getUserData = async (userId) => {
  try {
    const doc = await db.collection('users').doc(userId).get();
    if (doc.exists) {
      return { success: true, data: doc.data() };
    } else {
      return { success: false, error: 'User not found' };
    }
  } catch (error) {
    console.error("Error getting user data:", error);
    return { success: false, error };
  }
};

const updateUserData = async (userId, userData) => {
  try {
    await db.collection('users').doc(userId).update({
      ...userData,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error updating user data:", error);
    return { success: false, error };
  }
};

// Release management functions
const createRelease = async (userId, releaseData) => {
  try {
    // Create a new release document
    const releaseRef = await db.collection('releases').add({
      ...releaseData,
      userId: userId,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      status: 'draft',
      isApproved: false,
      isLive: false
    });
    
    // Update the release with its ID
    await releaseRef.update({
      releaseId: releaseRef.id
    });
    
    return { success: true, releaseId: releaseRef.id };
  } catch (error) {
    console.error("Error creating release:", error);
    return { success: false, error };
  }
};

const updateRelease = async (releaseId, releaseData) => {
  try {
    await db.collection('releases').doc(releaseId).update({
      ...releaseData,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error updating release:", error);
    return { success: false, error };
  }
};

const submitReleaseForReview = async (releaseId) => {
  try {
    await db.collection('releases').doc(releaseId).update({
      status: 'in_review',
      submittedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("Error submitting release for review:", error);
    return { success: false, error };
  }
};

const getUserReleases = async (userId) => {
  try {
    const snapshot = await db.collection('releases')
      .where('userId', '==', userId)
      .orderBy('createdAt', 'desc')
      .get();
    
    const releases = [];
    snapshot.forEach(doc => {
      releases.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, releases };
  } catch (error) {
    console.error("Error getting user releases:", error);
    return { success: false, error };
  }
};

// Storage helper functions
const uploadFile = async (file, path) => {
  try {
    const storageRef = storage.ref();
    const fileRef = storageRef.child(path);
    
    // Upload file
    const snapshot = await fileRef.put(file);
    
    // Get download URL
    const downloadURL = await snapshot.ref.getDownloadURL();
    
    return { success: true, downloadURL };
  } catch (error) {
    console.error("Error uploading file:", error);
    return { success: false, error };
  }
};

const deleteFile = async (path) => {
  try {
    const storageRef = storage.ref();
    const fileRef = storageRef.child(path);
    
    await fileRef.delete();
    
    return { success: true };
  } catch (error) {
    console.error("Error deleting file:", error);
    return { success: false, error };
  }
};

// Royalty management functions
const getUserRoyalties = async (userId) => {
  try {
    const snapshot = await db.collection('royalties')
      .where('userId', '==', userId)
      .orderBy('period', 'desc')
      .get();
    
    const royalties = [];
    snapshot.forEach(doc => {
      royalties.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, royalties };
  } catch (error) {
    console.error("Error getting user royalties:", error);
    return { success: false, error };
  }
};

const getRoyaltyDetails = async (royaltyId) => {
  try {
    const doc = await db.collection('royalties').doc(royaltyId).get();
    
    if (doc.exists) {
      // Get royalty breakdown
      const breakdownSnapshot = await db.collection('royalties')
        .doc(royaltyId)
        .collection('breakdown')
        .get();
      
      const breakdown = [];
      breakdownSnapshot.forEach(bdoc => {
        breakdown.push({ id: bdoc.id, ...bdoc.data() });
      });
      
      return { success: true, royalty: { id: doc.id, ...doc.data() }, breakdown };
    } else {
      return { success: false, error: 'Royalty not found' };
    }
  } catch (error) {
    console.error("Error getting royalty details:", error);
    return { success: false, error };
  }
};

// Collaborator management functions
const addCollaborator = async (releaseId, collaboratorData) => {
  try {
    // Check if user exists
    let userSnapshot;
    if (collaboratorData.email) {
      userSnapshot = await db.collection('users')
        .where('email', '==', collaboratorData.email)
        .limit(1)
        .get();
    }
    
    let collaboratorId = null;
    
    if (!userSnapshot || userSnapshot.empty) {
      // Create a new collaborator document
      const collaboratorRef = await db.collection('collaborators').add({
        ...collaboratorData,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        isRegistered: false
      });
      
      collaboratorId = collaboratorRef.id;
    } else {
      // Use existing user
      const userData = userSnapshot.docs[0].data();
      collaboratorId = userSnapshot.docs[0].id;
      collaboratorData.name = userData.name;
      collaboratorData.isRegistered = true;
    }
    
    // Add to release collaborators
    await db.collection('releases')
      .doc(releaseId)
      .collection('collaborators')
      .doc(collaboratorId)
      .set({
        ...collaboratorData,
        collaboratorId: collaboratorId,
        addedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    
    return { success: true, collaboratorId };
  } catch (error) {
    console.error("Error adding collaborator:", error);
    return { success: false, error };
  }
};

const getReleaseCollaborators = async (releaseId) => {
  try {
    const snapshot = await db.collection('releases')
      .doc(releaseId)
      .collection('collaborators')
      .get();
    
    const collaborators = [];
    snapshot.forEach(doc => {
      collaborators.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, collaborators };
  } catch (error) {
    console.error("Error getting release collaborators:", error);
    return { success: false, error };
  }
};

// Admin functions
const getAllUsers = async () => {
  try {
    const snapshot = await db.collection('users')
      .orderBy('createdAt', 'desc')
      .get();
    
    const users = [];
    snapshot.forEach(doc => {
      users.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, users };
  } catch (error) {
    console.error("Error getting all users:", error);
    return { success: false, error };
  }
};

const getAllReleases = async (status = null) => {
  try {
    let query = db.collection('releases').orderBy('createdAt', 'desc');
    
    if (status) {
      query = query.where('status', '==', status);
    }
    
    const snapshot = await query.get();
    
    const releases = [];
    snapshot.forEach(doc => {
      releases.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, releases };
  } catch (error) {
    console.error("Error getting all releases:", error);
    return { success: false, error };
  }
};

const approveRelease = async (releaseId, adminId, notes = '') => {
  try {
    await db.collection('releases').doc(releaseId).update({
      status: 'approved',
      isApproved: true,
      approvedBy: adminId,
      approvedAt: firebase.firestore.FieldValue.serverTimestamp(),
      adminNotes: notes
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error approving release:", error);
    return { success: false, error };
  }
};

const rejectRelease = async (releaseId, adminId, reason = '') => {
  try {
    await db.collection('releases').doc(releaseId).update({
      status: 'rejected',
      isApproved: false,
      rejectedBy: adminId,
      rejectedAt: firebase.firestore.FieldValue.serverTimestamp(),
      rejectionReason: reason
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error rejecting release:", error);
    return { success: false, error };
  }
};

const requestChanges = async (releaseId, adminId, changes = '') => {
  try {
    await db.collection('releases').doc(releaseId).update({
      status: 'changes_requested',
      requestedBy: adminId,
      requestedAt: firebase.firestore.FieldValue.serverTimestamp(),
      requestedChanges: changes
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error requesting changes:", error);
    return { success: false, error };
  }
};

// DSP management functions
const getAllDsps = async () => {
  try {
    const snapshot = await db.collection('dsps')
      .orderBy('name', 'asc')
      .get();
    
    const dsps = [];
    snapshot.forEach(doc => {
      dsps.push({ id: doc.id, ...doc.data() });
    });
    
    return { success: true, dsps };
  } catch (error) {
    console.error("Error getting all DSPs:", error);
    return { success: false, error };
  }
};

const addDsp = async (dspData) => {
  try {
    const dspRef = await db.collection('dsps').add({
      ...dspData,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      status: 'connected'
    });
    
    return { success: true, dspId: dspRef.id };
  } catch (error) {
    console.error("Error adding DSP:", error);
    return { success: false, error };
  }
};

const updateDsp = async (dspId, dspData) => {
  try {
    await db.collection('dsps').doc(dspId).update({
      ...dspData,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    
    return { success: true };
  } catch (error) {
    console.error("Error updating DSP:", error);
    return { success: false, error };
  }
};

// Export all functions
const FirebaseService = {
  // Auth
  createUser,
  loginUser,
  logoutUser,
  resetPassword,
  
  // User data
  getUserData,
  updateUserData,
  
  // Releases
  createRelease,
  updateRelease,
  submitReleaseForReview,
  getUserReleases,
  
  // Storage
  uploadFile,
  deleteFile,
  
  // Royalties
  getUserRoyalties,
  getRoyaltyDetails,
  
  // Collaborators
  addCollaborator,
  getReleaseCollaborators,
  
  // Admin
  getAllUsers,
  getAllReleases,
  approveRelease,
  rejectRelease,
  requestChanges,
  
  // DSPs
  getAllDsps,
  addDsp,
  updateDsp
};
