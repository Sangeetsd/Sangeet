// Authentication functionality for Sangeet Distribution
document.addEventListener('DOMContentLoaded', function() {
    // Import Firebase configuration
    // Firebase config is loaded in the main HTML file
    
    // DOM Elements - Login
    const loginForm = document.getElementById('loginForm');
    const loginEmail = document.getElementById('loginEmail');
    const loginPassword = document.getElementById('loginPassword');
    const loginError = document.getElementById('loginError');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    
    // DOM Elements - Signup
    const signupForm = document.getElementById('signupForm');
    const signupName = document.getElementById('signupName');
    const signupEmail = document.getElementById('signupEmail');
    const signupPassword = document.getElementById('signupPassword');
    const signupConfirmPassword = document.getElementById('signupConfirmPassword');
    const signupError = document.getElementById('signupError');
    
    // DOM Elements - Forgot Password
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const forgotPasswordEmail = document.getElementById('forgotPasswordEmail');
    const forgotPasswordError = document.getElementById('forgotPasswordError');
    const forgotPasswordSuccess = document.getElementById('forgotPasswordSuccess');
    
    // DOM Elements - Logout
    const logoutBtn = document.getElementById('logoutBtn');
    
    // Login Form Submission
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Clear previous errors
            if (loginError) loginError.textContent = '';
            
            // Get form values
            const email = loginEmail.value.trim();
            const password = loginPassword.value;
            
            // Validate form
            if (!email || !password) {
                if (loginError) loginError.textContent = 'Please enter both email and password.';
                return;
            }
            
            // Show loading state
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
            
            try {
                // Sign in with Firebase
                const result = await firebase.auth().signInWithEmailAndPassword(email, password);
                
                // Check if user is verified
                if (result.user && !result.user.emailVerified) {
                    // Send verification email
                    await result.user.sendEmailVerification();
                    
                    // Sign out the user
                    await firebase.auth().signOut();
                    
                    if (loginError) loginError.textContent = 'Please verify your email before logging in. A new verification email has been sent.';
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalBtnText;
                    return;
                }
                
                // Check user role and redirect accordingly
                const userDoc = await firebase.firestore().collection('users').doc(result.user.uid).get();
                
                if (userDoc.exists) {
                    const userData = userDoc.data();
                    
                    if (userData.role === 'admin') {
                        // Redirect to admin dashboard
                        window.location.href = '../admin/index.html';
                    } else {
                        // Redirect to user dashboard
                        window.location.href = 'index.html';
                    }
                } else {
                    // User document doesn't exist, create one
                    await firebase.firestore().collection('users').doc(result.user.uid).set({
                        name: result.user.displayName || email.split('@')[0],
                        email: email,
                        role: 'artist',
                        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                        status: 'active'
                    });
                    
                    // Redirect to user dashboard
                    window.location.href = 'index.html';
                }
            } catch (error) {
                console.error('Login error:', error);
                
                // Handle specific error codes
                switch (error.code) {
                    case 'auth/user-not-found':
                    case 'auth/wrong-password':
                        if (loginError) loginError.textContent = 'Invalid email or password.';
                        break;
                    case 'auth/too-many-requests':
                        if (loginError) loginError.textContent = 'Too many failed login attempts. Please try again later.';
                        break;
                    case 'auth/user-disabled':
                        if (loginError) loginError.textContent = 'This account has been disabled. Please contact support.';
                        break;
                    default:
                        if (loginError) loginError.textContent = 'An error occurred. Please try again.';
                }
                
                // Reset button
                submitBtn.disabled = false;
                submitBtn.textContent = originalBtnText;
            }
        });
    }
    
    // Signup Form Submission
    if (signupForm) {
        signupForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Clear previous errors
            if (signupError) signupError.textContent = '';
            
            // Get form values
            const name = signupName.value.trim();
            const email = signupEmail.value.trim();
            const password = signupPassword.value;
            const confirmPassword = signupConfirmPassword.value;
            
            // Validate form
            if (!name || !email || !password || !confirmPassword) {
                if (signupError) signupError.textContent = 'Please fill in all fields.';
                return;
            }
            
            if (password !== confirmPassword) {
                if (signupError) signupError.textContent = 'Passwords do not match.';
                return;
            }
            
            if (password.length < 8) {
                if (signupError) signupError.textContent = 'Password must be at least 8 characters long.';
                return;
            }
            
            // Show loading state
            const submitBtn = signupForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating account...';
            
            try {
                // Create user with Firebase
                const result = await firebase.auth().createUserWithEmailAndPassword(email, password);
                
                // Update user profile
                await result.user.updateProfile({
                    displayName: name
                });
                
                // Send verification email
                await result.user.sendEmailVerification();
                
                // Create user document in Firestore
                await firebase.firestore().collection('users').doc(result.user.uid).set({
                    name: name,
                    email: email,
                    role: 'artist',
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                    isVerified: false,
                    status: 'active'
                });
                
                // Sign out the user
                await firebase.auth().signOut();
                
                // Show success message and redirect to login
                alert('Account created successfully! Please check your email to verify your account before logging in.');
                window.location.href = 'login.html';
            } catch (error) {
                console.error('Signup error:', error);
                
                // Handle specific error codes
                switch (error.code) {
                    case 'auth/email-already-in-use':
                        if (signupError) signupError.textContent = 'This email is already in use.';
                        break;
                    case 'auth/invalid-email':
                        if (signupError) signupError.textContent = 'Please enter a valid email address.';
                        break;
                    case 'auth/weak-password':
                        if (signupError) signupError.textContent = 'Password is too weak. Please use a stronger password.';
                        break;
                    default:
                        if (signupError) signupError.textContent = 'An error occurred. Please try again.';
                }
                
                // Reset button
                submitBtn.disabled = false;
                submitBtn.textContent = originalBtnText;
            }
        });
    }
    
    // Forgot Password Form Submission
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Clear previous messages
            if (forgotPasswordError) forgotPasswordError.textContent = '';
            if (forgotPasswordSuccess) forgotPasswordSuccess.textContent = '';
            
            // Get form values
            const email = forgotPasswordEmail.value.trim();
            
            // Validate form
            if (!email) {
                if (forgotPasswordError) forgotPasswordError.textContent = 'Please enter your email address.';
                return;
            }
            
            // Show loading state
            const submitBtn = forgotPasswordForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.textContent;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            
            try {
                // Send password reset email
                await firebase.auth().sendPasswordResetEmail(email);
                
                // Show success message
                if (forgotPasswordSuccess) forgotPasswordSuccess.textContent = 'Password reset email sent. Please check your inbox.';
                forgotPasswordEmail.value = '';
            } catch (error) {
                console.error('Forgot password error:', error);
                
                // Handle specific error codes
                switch (error.code) {
                    case 'auth/user-not-found':
                        if (forgotPasswordError) forgotPasswordError.textContent = 'No account found with this email address.';
                        break;
                    case 'auth/invalid-email':
                        if (forgotPasswordError) forgotPasswordError.textContent = 'Please enter a valid email address.';
                        break;
                    default:
                        if (forgotPasswordError) forgotPasswordError.textContent = 'An error occurred. Please try again.';
                }
            } finally {
                // Reset button
                submitBtn.disabled = false;
                submitBtn.textContent = originalBtnText;
            }
        });
    }
    
    // Logout Button
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            
            try {
                // Sign out with Firebase
                await firebase.auth().signOut();
                
                // Redirect to login page
                window.location.href = 'login.html';
            } catch (error) {
                console.error('Logout error:', error);
                alert('An error occurred while logging out. Please try again.');
            }
        });
    }
    
    // Check authentication state
    firebase.auth().onAuthStateChanged(function(user) {
        // Get current page path
        const path = window.location.pathname;
        
        if (user) {
            // User is signed in
            
            // If on login or signup page, redirect to dashboard
            if (path.includes('login.html') || path.includes('signup.html')) {
                // Check user role and redirect accordingly
                firebase.firestore().collection('users').doc(user.uid).get()
                    .then((doc) => {
                        if (doc.exists) {
                            const userData = doc.data();
                            
                            if (userData.role === 'admin') {
                                // Redirect to admin dashboard
                                window.location.href = '../admin/index.html';
                            } else {
                                // Redirect to user dashboard
                                window.location.href = 'index.html';
                            }
                        } else {
                            // User document doesn't exist, redirect to user dashboard
                            window.location.href = 'index.html';
                        }
                    })
                    .catch((error) => {
                        console.error('Error checking user role:', error);
                        window.location.href = 'index.html';
                    });
            }
        } else {
            // No user is signed in
            
            // If on dashboard or protected page, redirect to login
            if (path.includes('/dashboard/') && !path.includes('login.html') && !path.includes('signup.html')) {
                window.location.href = 'login.html';
            }
            
            // If on admin page, redirect to login
            if (path.includes('/admin/')) {
                window.location.href = '../dashboard/login.html';
            }
        }
    });
});
