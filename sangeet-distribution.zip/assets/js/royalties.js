// Royalty management functionality for Sangeet Distribution
document.addEventListener('DOMContentLoaded', function() {
    // Import Firebase configuration
    // Firebase config is loaded in the main HTML file
    
    // DOM Elements - Royalty Dashboard
    const royaltyTotalElement = document.getElementById('royaltyTotal');
    const royaltyPeriodSelectElement = document.getElementById('royaltyPeriodSelect');
    const royaltyChartElement = document.getElementById('royaltyChart');
    const dspBreakdownChartElement = document.getElementById('dspBreakdownChart');
    const trackBreakdownChartElement = document.getElementById('trackBreakdownChart');
    const royaltyTableElement = document.getElementById('royaltyTable');
    
    // Variables
    let currentUser = null;
    let royaltyChart = null;
    let dspBreakdownChart = null;
    let trackBreakdownChart = null;
    let currentPeriod = 'all';
    
    // Check authentication state
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            // User is signed in
            currentUser = user;
            
            // Initialize royalty dashboard
            initializeRoyaltyDashboard();
        }
    });
    
    // Initialize Royalty Dashboard
    function initializeRoyaltyDashboard() {
        // Load royalty periods for dropdown
        loadRoyaltyPeriods();
        
        // Load royalty data
        loadRoyaltyData();
        
        // Add event listener for period select
        if (royaltyPeriodSelectElement) {
            royaltyPeriodSelectElement.addEventListener('change', function() {
                currentPeriod = this.value;
                loadRoyaltyData();
            });
        }
    }
    
    // Load Royalty Periods
    async function loadRoyaltyPeriods() {
        if (!royaltyPeriodSelectElement) return;
        
        try {
            // Get royalty periods from Firestore
            const royaltiesSnapshot = await firebase.firestore().collection('royalties')
                .where('userId', '==', currentUser.uid)
                .orderBy('period', 'desc')
                .get();
            
            if (royaltiesSnapshot.empty) {
                // No royalties found, disable select
                royaltyPeriodSelectElement.disabled = true;
                return;
            }
            
            // Enable select
            royaltyPeriodSelectElement.disabled = false;
            
            // Get unique periods
            const periods = new Set();
            
            royaltiesSnapshot.forEach(doc => {
                const royaltyData = doc.data();
                if (royaltyData.period) {
                    periods.add(royaltyData.period);
                }
            });
            
            // Add periods to dropdown
            let html = '<option value="all">All Time</option>';
            
            Array.from(periods).forEach(period => {
                // Format period (YYYY-MM) to MMM YYYY
                const year = period.substring(0, 4);
                const month = period.substring(5, 7);
                const date = new Date(year, month - 1);
                const formattedPeriod = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
                
                html += `<option value="${period}">${formattedPeriod}</option>`;
            });
            
            royaltyPeriodSelectElement.innerHTML = html;
        } catch (error) {
            console.error('Error loading royalty periods:', error);
        }
    }
    
    // Load Royalty Data
    async function loadRoyaltyData() {
        try {
            // Build query
            let query = firebase.firestore().collection('royalties')
                .where('userId', '==', currentUser.uid)
                .orderBy('period', 'desc');
            
            // Apply period filter
            if (currentPeriod !== 'all') {
                query = query.where('period', '==', currentPeriod);
            }
            
            // Get royalties
            const royaltiesSnapshot = await query.get();
            
            if (royaltiesSnapshot.empty) {
                // No royalties found
                if (royaltyTotalElement) {
                    royaltyTotalElement.textContent = formatCurrency(0);
                }
                
                // Clear charts
                clearCharts();
                
                // Clear table
                if (royaltyTableElement) {
                    royaltyTableElement.innerHTML = '<tr><td colspan="5" class="text-center">No royalty data available</td></tr>';
                }
                
                return;
            }
            
            // Process royalty data
            let totalAmount = 0;
            const periodData = {};
            const dspData = {};
            const trackData = {};
            const tableData = [];
            
            royaltiesSnapshot.forEach(doc => {
                const royaltyData = doc.data();
                
                // Add to total
                totalAmount += royaltyData.amount || 0;
                
                // Add to period data
                if (royaltyData.period) {
                    if (!periodData[royaltyData.period]) {
                        periodData[royaltyData.period] = 0;
                    }
                    periodData[royaltyData.period] += royaltyData.amount || 0;
                }
                
                // Add to DSP data
                if (royaltyData.dspBreakdown) {
                    Object.keys(royaltyData.dspBreakdown).forEach(dsp => {
                        if (!dspData[dsp]) {
                            dspData[dsp] = 0;
                        }
                        dspData[dsp] += royaltyData.dspBreakdown[dsp].amount || 0;
                    });
                }
                
                // Add to track data
                if (royaltyData.trackBreakdown) {
                    Object.keys(royaltyData.trackBreakdown).forEach(track => {
                        if (!trackData[track]) {
                            trackData[track] = 0;
                        }
                        trackData[track] += royaltyData.trackBreakdown[track].amount || 0;
                    });
                }
                
                // Add to table data
                tableData.push({
                    id: doc.id,
                    ...royaltyData
                });
            });
            
            // Update total
            if (royaltyTotalElement) {
                royaltyTotalElement.textContent = formatCurrency(totalAmount);
            }
            
            // Update charts
            updateRoyaltyChart(periodData);
            updateDspBreakdownChart(dspData);
            updateTrackBreakdownChart(trackData);
            
            // Update table
            updateRoyaltyTable(tableData);
        } catch (error) {
            console.error('Error loading royalty data:', error);
        }
    }
    
    // Update Royalty Chart
    function updateRoyaltyChart(periodData) {
        if (!royaltyChartElement) return;
        
        // Sort periods
        const sortedPeriods = Object.keys(periodData).sort();
        
        // Prepare chart data
        const labels = [];
        const data = [];
        
        sortedPeriods.forEach(period => {
            // Format period (YYYY-MM) to MMM YYYY
            const year = period.substring(0, 4);
            const month = period.substring(5, 7);
            const date = new Date(year, month - 1);
            const formattedPeriod = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            
            labels.push(formattedPeriod);
            data.push(periodData[period]);
        });
        
        // Create or update chart
        if (royaltyChart) {
            royaltyChart.data.labels = labels;
            royaltyChart.data.datasets[0].data = data;
            royaltyChart.update();
        } else {
            const ctx = royaltyChartElement.getContext('2d');
            royaltyChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Earnings',
                        data: data,
                        backgroundColor: 'rgba(138, 79, 255, 0.1)',
                        borderColor: 'rgba(138, 79, 255, 1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return formatCurrency(context.raw);
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return formatCurrency(value, true);
                                }
                            }
                        }
                    }
                }
            });
        }
    }
    
    // Update DSP Breakdown Chart
    function updateDspBreakdownChart(dspData) {
        if (!dspBreakdownChartElement) return;
        
        // Sort DSPs by amount
        const sortedDsps = Object.keys(dspData).sort((a, b) => dspData[b] - dspData[a]);
        
        // Prepare chart data
        const labels = [];
        const data = [];
        const colors = [];
        
        sortedDsps.forEach(dsp => {
            labels.push(dsp);
            data.push(dspData[dsp]);
            colors.push(getDspColor(dsp));
        });
        
        // Create or update chart
        if (dspBreakdownChart) {
            dspBreakdownChart.data.labels = labels;
            dspBreakdownChart.data.datasets[0].data = data;
            dspBreakdownChart.data.datasets[0].backgroundColor = colors;
            dspBreakdownChart.update();
        } else {
            const ctx = dspBreakdownChartElement.getContext('2d');
            dspBreakdownChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: colors,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ${formatCurrency(value)} (${percentage}%)`;
                                }
                            }
                        }
                    },
                    cutout: '70%'
                }
            });
        }
    }
    
    // Update Track Breakdown Chart
    function updateTrackBreakdownChart(trackData) {
        if (!trackBreakdownChartElement) return;
        
        // Sort tracks by amount and limit to top 10
        const sortedTracks = Object.keys(trackData)
            .sort((a, b) => trackData[b] - trackData[a])
            .slice(0, 10);
        
        // Prepare chart data
        const labels = [];
        const data = [];
        
        sortedTracks.forEach(track => {
            // Truncate long track names
            const truncatedTrack = track.length > 25 ? track.substring(0, 22) + '...' : track;
            labels.push(truncatedTrack);
            data.push(trackData[track]);
        });
        
        // Create or update chart
        if (trackBreakdownChart) {
            trackBreakdownChart.data.labels = labels;
            trackBreakdownChart.data.datasets[0].data = data;
            trackBreakdownChart.update();
        } else {
            const ctx = trackBreakdownChartElement.getContext('2d');
            trackBreakdownChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Earnings',
                        data: data,
                        backgroundColor: 'rgba(0, 168, 225, 0.7)',
                        borderWidth: 0,
                        borderRadius: 5
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return formatCurrency(context.raw);
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return formatCurrency(value, true);
                                }
                            }
                        }
                    }
                }
            });
        }
    }
    
    // Update Royalty Table
    function updateRoyaltyTable(tableData) {
        if (!royaltyTableElement) return;
        
        if (tableData.length === 0) {
            royaltyTableElement.innerHTML = '<tr><td colspan="5" class="text-center">No royalty data available</td></tr>';
            return;
        }
        
        let html = '';
        
        tableData.forEach(royalty => {
            // Format period
            let formattedPeriod = 'N/A';
            if (royalty.period) {
                const year = royalty.period.substring(0, 4);
                const month = royalty.period.substring(5, 7);
                const date = new Date(year, month - 1);
                formattedPeriod = date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            }
            
            // Format payment date
            let formattedPaymentDate = 'Pending';
            if (royalty.paymentDate) {
                const paymentDate = new Date(royalty.paymentDate.toDate());
                formattedPaymentDate = paymentDate.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
            }
            
            // Get top DSP
            let topDsp = 'N/A';
            let topDspAmount = 0;
            
            if (royalty.dspBreakdown) {
                Object.keys(royalty.dspBreakdown).forEach(dsp => {
                    const amount = royalty.dspBreakdown[dsp].amount || 0;
                    if (amount > topDspAmount) {
                        topDsp = dsp;
                        topDspAmount = amount;
                    }
                });
            }
            
            html += `
                <tr>
                    <td>${formattedPeriod}</td>
                    <td>${formatCurrency(royalty.amount || 0)}</td>
                    <td>${formatNumber(royalty.streams || 0)}</td>
                    <td>${topDsp}</td>
                    <td>${formattedPaymentDate}</td>
                    <td>
                        <button class="action-btn view-details" data-id="${royalty.id}" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        
        royaltyTableElement.innerHTML = html;
        
        // Add event listeners for view details buttons
        const viewDetailsButtons = document.querySelectorAll('.view-details');
        viewDetailsButtons.forEach(button => {
            button.addEventListener('click', function() {
                const royaltyId = this.dataset.id;
                showRoyaltyDetails(royaltyId);
            });
        });
    }
    
    // Show Royalty Details
    async function showRoyaltyDetails(royaltyId) {
        try {
            // Get royalty data
            const royaltyDoc = await firebase.firestore().collection('royalties').doc(royaltyId).get();
            
            if (!royaltyDoc.exists) {
                alert('Royalty data not found.');
                return;
            }
            
            const royaltyData = royaltyDoc.data();
            
            // Format period
            let formattedPeriod = 'N/A';
            if (royaltyData.period) {
                const year = royaltyData.period.substring(0, 4);
                const month = royaltyData.period.substring(5, 7);
                const date = new Date(year, month - 1);
                formattedPeriod = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
            }
            
            // Create modal content
            let modalContent = `
                <div class="royalty-details-modal">
                    <div class="royalty-details-header">
                        <h2>Royalty Details - ${formattedPeriod}</h2>
                    </div>
                    <div class="royalty-details-summary">
                        <div class="summary-item">
                            <div class="summary-label">Total Earnings</div>
                            <div class="summary-value">${formatCurrency(royaltyData.amount || 0)}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Total Streams</div>
                            <div class="summary-value">${formatNumber(royaltyData.streams || 0)}</div>
                        </div>
                        <div class="summary-item">
                            <div class="summary-label">Average Per Stream</div>
                            <div class="summary-value">${royaltyData.streams ? formatCurrency(royaltyData.amount / royaltyData.streams) : 'N/A'}</div>
                        </div>
                    </div>
                    
                    <div class="royalty-details-section">
                        <h3>DSP Breakdown</h3>
                        <table class="royalty-details-table">
                            <thead>
                                <tr>
                                    <th>DSP</th>
                                    <th>Streams</th>
                                    <th>Earnings</th>
                                    <th>Per Stream</th>
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            // Add DSP breakdown
            if (royaltyData.dspBreakdown) {
                const dsps = Object.keys(royaltyData.dspBreakdown).sort((a, b) => {
                    return (royaltyData.dspBreakdown[b].amount || 0) - (royaltyData.dspBreakdown[a].amount || 0);
                });
                
                dsps.forEach(dsp => {
                    const dspData = royaltyData.dspBreakdown[dsp];
                    const streams = dspData.streams || 0;
                    const amount = dspData.amount || 0;
                    const perStream = streams > 0 ? amount / streams : 0;
                    
                    modalContent += `
                        <tr>
                            <td>${dsp}</td>
                            <td>${formatNumber(streams)}</td>
                            <td>${formatCurrency(amount)}</td>
                            <td>${formatCurrency(perStream)}</td>
                        </tr>
                    `;
                });
            } else {
                modalContent += `
                    <tr>
                        <td colspan="4" class="text-center">No DSP breakdown available</td>
                    </tr>
                `;
            }
            
            modalContent += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="royalty-details-section">
                        <h3>Track Breakdown</h3>
                        <table class="royalty-details-table">
                            <thead>
                                <tr>
                                    <th>Track</th>
                                    <th>Streams</th>
                                    <th>Earnings</th>
                                    <th>Per Stream</th>
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            // Add track breakdown
            if (royaltyData.trackBreakdown) {
                const tracks = Object.keys(royaltyData.trackBreakdown).sort((a, b) => {
                    return (royaltyData.trackBreakdown[b].amount || 0) - (royaltyData.trackBreakdown[a].amount || 0);
                });
                
                tracks.forEach(track => {
                    const trackData = royaltyData.trackBreakdown[track];
                    const streams = trackData.streams || 0;
                    const amount = trackData.amount || 0;
                    const perStream = streams > 0 ? amount / streams : 0;
                    
                    modalContent += `
                        <tr>
                            <td>${track}</td>
                            <td>${formatNumber(streams)}</td>
                            <td>${formatCurrency(amount)}</td>
                            <td>${formatCurrency(perStream)}</td>
                        </tr>
                    `;
                });
            } else {
                modalContent += `
                    <tr>
                        <td colspan="4" class="text-center">No track breakdown available</td>
                    </tr>
                `;
            }
            
            modalContent += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="royalty-details-footer">
                        <button class="btn btn-primary close-modal">Close</button>
                    </div>
                </div>
            `;
            
            // Create modal
            const modalOverlay = document.createElement('div');
            modalOverlay.className = 'modal-overlay';
            modalOverlay.innerHTML = `
                <div class="modal-container">
                    ${modalContent}
                </div>
            `;
            
            document.body.appendChild(modalOverlay);
            
            // Add event listener for close button
            const closeButton = modalOverlay.querySelector('.close-modal');
            closeButton.addEventListener('click', function() {
                document.body.removeChild(modalOverlay);
            });
            
            // Close modal when clicking outside
            modalOverlay.addEventListener('click', function(e) {
                if (e.target === modalOverlay) {
                    document.body.removeChild(modalOverlay);
                }
            });
        } catch (error) {
            console.error('Error showing royalty details:', error);
            alert('An error occurred while loading royalty details. Please try again.');
        }
    }
    
    // Clear Charts
    function clearCharts() {
        if (royaltyChart) {
            royaltyChart.data.labels = [];
            royaltyChart.data.datasets[0].data = [];
            royaltyChart.update();
        }
        
        if (dspBreakdownChart) {
            dspBreakdownChart.data.labels = [];
            dspBreakdownChart.data.datasets[0].data = [];
            dspBreakdownChart.update();
        }
        
        if (trackBreakdownChart) {
            trackBreakdownChart.data.labels = [];
            trackBreakdownChart.data.datasets[0].data = [];
            trackBreakdownChart.update();
        }
    }
    
    // Helper Functions
    function formatNumber(num, abbreviated = false) {
        if (abbreviated) {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            }
            if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            }
            return num.toString();
        }
        
        return new Intl.NumberFormat().format(num);
    }
    
    function formatCurrency(amount, abbreviated = false) {
        if (abbreviated) {
            if (amount >= 1000000) {
                return '₹' + (amount / 1000000).toFixed(1) + 'M';
            }
            if (amount >= 1000) {
                return '₹' + (amount / 1000).toFixed(1) + 'K';
            }
            return '₹' + amount.toFixed(2);
        }
        
        return new Intl.NumberFormat('en-IN', { 
            style: 'currency', 
            currency: 'INR',
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    function getDspColor(dsp) {
        const lowerDsp = dsp.toLowerCase();
        
        if (lowerDsp.includes('spotify')) return '#1DB954';
        if (lowerDsp.includes('apple')) return '#FC3C44';
        if (lowerDsp.includes('youtube')) return '#FF0000';
        if (lowerDsp.includes('amazon')) return '#00A8E1';
        if (lowerDsp.includes('jiosaavn')) return '#2BC5B4';
        if (lowerDsp.includes('gaana')) return '#E72C30';
        if (lowerDsp.includes('wynk')) return '#FF5722';
        if (lowerDsp.includes('resso')) return '#00C2FF';
        
        // Default color if no match
        return '#' + Math.floor(Math.random() * 16777215).toString(16);
    }
});
