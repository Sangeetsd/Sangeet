// Release management functionality for Sangeet Distribution
document.addEventListener('DOMContentLoaded', function() {
    // Import Firebase configuration
    // Firebase config is loaded in the main HTML file
    
    // DOM Elements - Upload Form
    const uploadForm = document.getElementById('uploadForm');
    const releaseTitle = document.getElementById('releaseTitle');
    const primaryArtist = document.getElementById('primaryArtist');
    const releaseType = document.getElementById('releaseType');
    const genre = document.getElementById('genre');
    const language = document.getElementById('language');
    const releaseDate = document.getElementById('releaseDate');
    const coverArtUpload = document.getElementById('coverArtUpload');
    const coverArtPreview = document.getElementById('coverArtPreview');
    const upc = document.getElementById('upc');
    const uploadError = document.getElementById('uploadError');
    
    // DOM Elements - Track Upload
    const trackUploadContainer = document.getElementById('trackUploadContainer');
    const addTrackBtn = document.getElementById('addTrackBtn');
    
    // DOM Elements - DSP Selection
    const dspSelectionContainer = document.getElementById('dspSelectionContainer');
    
    // DOM Elements - Release List
    const releasesListElement = document.getElementById('releasesList');
    const releasesPaginationElement = document.getElementById('releasesPagination');
    const releaseFilters = document.getElementById('releaseFilters');
    const releaseSearch = document.getElementById('releaseSearch');
    
    // DOM Elements - Release Details
    const releaseDetailsContainer = document.getElementById('releaseDetailsContainer');
    const releaseDetailsCoverArt = document.getElementById('releaseDetailsCoverArt');
    const releaseDetailsTitle = document.getElementById('releaseDetailsTitle');
    const releaseDetailsArtist = document.getElementById('releaseDetailsArtist');
    const releaseDetailsType = document.getElementById('releaseDetailsType');
    const releaseDetailsGenre = document.getElementById('releaseDetailsGenre');
    const releaseDetailsLanguage = document.getElementById('releaseDetailsLanguage');
    const releaseDetailsReleaseDate = document.getElementById('releaseDetailsReleaseDate');
    const releaseDetailsUPC = document.getElementById('releaseDetailsUPC');
    const releaseDetailsStatus = document.getElementById('releaseDetailsStatus');
    const releaseDetailsSubmittedDate = document.getElementById('releaseDetailsSubmittedDate');
    const releaseDetailsTrackList = document.getElementById('releaseDetailsTrackList');
    const releaseDetailsDSPs = document.getElementById('releaseDetailsDSPs');
    
    // Variables
    let currentUser = null;
    let currentReleaseId = null;
    let tracks = [];
    let selectedDSPs = [];
    let currentPage = 1;
    let totalPages = 1;
    let pageSize = 10;
    
    // Check authentication state
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            // User is signed in
            currentUser = user;
            
            // Check if we're on the upload page
            if (uploadForm) {
                // Check if we're editing an existing release
                const urlParams = new URLSearchParams(window.location.search);
                const releaseId = urlParams.get('id');
                
                if (releaseId) {
                    // Load release data for editing
                    loadReleaseForEditing(releaseId);
                } else {
                    // Initialize new release form
                    initializeUploadForm();
                }
            }
            
            // Check if we're on the releases page
            if (releasesListElement) {
                // Load releases
                loadReleases();
                
                // Initialize filters
                initializeFilters();
            }
            
            // Check if we're on the release details page
            if (releaseDetailsContainer) {
                // Get release ID from URL
                const urlParams = new URLSearchParams(window.location.search);
                const releaseId = urlParams.get('id');
                
                if (releaseId) {
                    // Load release details
                    loadReleaseDetails(releaseId);
                } else {
                    // Redirect to releases page
                    window.location.href = 'releases.html';
                }
            }
        }
    });
    
    // Initialize Upload Form
    function initializeUploadForm() {
        // Set minimum release date to today
        const today = new Date();
        const minDate = today.toISOString().split('T')[0];
        
        if (releaseDate) {
            releaseDate.min = minDate;
            
            // Set default release date to 2 weeks from today
            const twoWeeksLater = new Date(today);
            twoWeeksLater.setDate(today.getDate() + 14);
            releaseDate.value = twoWeeksLater.toISOString().split('T')[0];
        }
        
        // Initialize cover art upload
        if (coverArtUpload) {
            coverArtUpload.addEventListener('change', handleCoverArtUpload);
        }
        
        // Initialize track upload
        if (addTrackBtn) {
            addTrackBtn.addEventListener('click', addTrackUploadField);
            
            // Add initial track upload field
            addTrackUploadField();
        }
        
        // Load DSPs
        loadDSPs();
        
        // Initialize form submission
        if (uploadForm) {
            uploadForm.addEventListener('submit', handleReleaseSubmission);
        }
    }
    
    // Handle Cover Art Upload
    function handleCoverArtUpload(e) {
        const file = e.target.files[0];
        
        if (!file) return;
        
        // Validate file type
        const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            alert('Please upload a valid image file (JPEG, PNG, or WebP).');
            e.target.value = '';
            return;
        }
        
        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert('Image file size must be less than 5MB.');
            e.target.value = '';
            return;
        }
        
        // Show preview
        if (coverArtPreview) {
            const reader = new FileReader();
            reader.onload = function(e) {
                coverArtPreview.src = e.target.result;
                coverArtPreview.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    }
    
    // Add Track Upload Field
    function addTrackUploadField() {
        if (!trackUploadContainer) return;
        
        const trackIndex = tracks.length;
        
        const trackDiv = document.createElement('div');
        trackDiv.className = 'track-upload-item';
        trackDiv.dataset.index = trackIndex;
        
        trackDiv.innerHTML = `
            <div class="track-header">
                <h4>Track ${trackIndex + 1}</h4>
                ${trackIndex > 0 ? '<button type="button" class="remove-track-btn"><i class="fas fa-times"></i></button>' : ''}
            </div>
            <div class="form-group">
                <label for="trackTitle${trackIndex}">Track Title *</label>
                <input type="text" id="trackTitle${trackIndex}" class="form-control track-title" required>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="trackArtist${trackIndex}">Artist *</label>
                    <input type="text" id="trackArtist${trackIndex}" class="form-control track-artist" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="trackFeaturing${trackIndex}">Featuring</label>
                    <input type="text" id="trackFeaturing${trackIndex}" class="form-control track-featuring" placeholder="Optional">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="trackISRC${trackIndex}">ISRC</label>
                    <input type="text" id="trackISRC${trackIndex}" class="form-control track-isrc" placeholder="Optional">
                </div>
                <div class="form-group col-md-6">
                    <label for="trackExplicit${trackIndex}">Explicit</label>
                    <select id="trackExplicit${trackIndex}" class="form-control track-explicit">
                        <option value="false">No</option>
                        <option value="true">Yes</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="trackFile${trackIndex}">Audio File (WAV/MP3) *</label>
                <div class="file-upload-container">
                    <input type="file" id="trackFile${trackIndex}" class="track-file" accept=".wav,.mp3" required>
                    <div class="file-upload-label">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <span>Drag & drop file or click to browse</span>
                    </div>
                </div>
                <div class="file-info" id="trackFileInfo${trackIndex}"></div>
            </div>
            <div class="form-group">
                <label for="trackLyrics${trackIndex}">Lyrics</label>
                <textarea id="trackLyrics${trackIndex}" class="form-control track-lyrics" rows="3" placeholder="Optional"></textarea>
            </div>
        `;
        
        trackUploadContainer.appendChild(trackDiv);
        
        // Add event listener for file upload
        const trackFileInput = document.getElementById(`trackFile${trackIndex}`);
        if (trackFileInput) {
            trackFileInput.addEventListener('change', function(e) {
                handleTrackFileUpload(e, trackIndex);
            });
        }
        
        // Add event listener for remove button
        const removeBtn = trackDiv.querySelector('.remove-track-btn');
        if (removeBtn) {
            removeBtn.addEventListener('click', function() {
                removeTrackUploadField(trackIndex);
            });
        }
        
        // Add track to tracks array
        tracks.push({
            index: trackIndex,
            file: null
        });
    }
    
    // Handle Track File Upload
    function handleTrackFileUpload(e, index) {
        const file = e.target.files[0];
        const fileInfoElement = document.getElementById(`trackFileInfo${index}`);
        
        if (!file) return;
        
        // Validate file type
        const validTypes = ['audio/wav', 'audio/mpeg', 'audio/mp3'];
        if (!validTypes.includes(file.type) && !file.name.endsWith('.wav') && !file.name.endsWith('.mp3')) {
            alert('Please upload a valid audio file (WAV or MP3).');
            e.target.value = '';
            if (fileInfoElement) fileInfoElement.textContent = '';
            return;
        }
        
        // Validate file size (max 50MB)
        if (file.size > 50 * 1024 * 1024) {
            alert('Audio file size must be less than 50MB.');
            e.target.value = '';
            if (fileInfoElement) fileInfoElement.textContent = '';
            return;
        }
        
        // Update file info
        if (fileInfoElement) {
            fileInfoElement.textContent = `${file.name} (${formatFileSize(file.size)})`;
        }
        
        // Update tracks array
        tracks[index].file = file;
    }
    
    // Remove Track Upload Field
    function removeTrackUploadField(index) {
        const trackDiv = trackUploadContainer.querySelector(`.track-upload-item[data-index="${index}"]`);
        
        if (trackDiv) {
            trackUploadContainer.removeChild(trackDiv);
            
            // Remove track from tracks array
            tracks = tracks.filter(track => track.index !== index);
            
            // Renumber remaining tracks
            const trackDivs = trackUploadContainer.querySelectorAll('.track-upload-item');
            trackDivs.forEach((div, i) => {
                div.querySelector('h4').textContent = `Track ${i + 1}`;
            });
        }
    }
    
    // Load DSPs
    async function loadDSPs() {
        if (!dspSelectionContainer) return;
        
        try {
            // Get DSPs from Firestore
            const dspsSnapshot = await firebase.firestore().collection('dsps')
                .where('status', '==', 'active')
                .get();
            
            if (dspsSnapshot.empty) {
                dspSelectionContainer.innerHTML = '<p>No DSPs available</p>';
                return;
            }
            
            let html = '<div class="dsp-grid">';
            
            dspsSnapshot.forEach(doc => {
                const dspData = doc.data();
                const dspId = doc.id;
                
                html += `
                    <div class="dsp-item">
                        <input type="checkbox" id="dsp_${dspId}" class="dsp-checkbox" value="${dspId}">
                        <label for="dsp_${dspId}">
                            <img src="${dspData.logoURL || '../assets/images/dsp-placeholder.png'}" alt="${dspData.name}">
                            <span>${dspData.name}</span>
                        </label>
                    </div>
                `;
            });
            
            html += '</div>';
            
            dspSelectionContainer.innerHTML = html;
            
            // Add event listeners for DSP checkboxes
            const dspCheckboxes = document.querySelectorAll('.dsp-checkbox');
            dspCheckboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    if (this.checked) {
                        selectedDSPs.push(this.value);
                    } else {
                        selectedDSPs = selectedDSPs.filter(dsp => dsp !== this.value);
                    }
                });
                
                // Check all DSPs by default
                checkbox.checked = true;
                selectedDSPs.push(checkbox.value);
            });
        } catch (error) {
            console.error('Error loading DSPs:', error);
            dspSelectionContainer.innerHTML = '<p>Error loading DSPs</p>';
        }
    }
    
    // Handle Release Submission
    async function handleReleaseSubmission(e) {
        e.preventDefault();
        
        // Clear previous errors
        if (uploadError) uploadError.textContent = '';
        
        // Validate form
        if (!validateReleaseForm()) return;
        
        // Show loading state
        const submitBtn = uploadForm.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.textContent;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
        
        try {
            // Upload cover art
            const coverArtFile = coverArtUpload.files[0];
            let coverArtURL = '';
            
            if (coverArtFile) {
                const coverArtRef = firebase.storage().ref().child(`releases/${currentUser.uid}/${Date.now()}_cover.jpg`);
                await coverArtRef.put(coverArtFile);
                coverArtURL = await coverArtRef.getDownloadURL();
            }
            
            // Prepare release data
            const releaseData = {
                title: releaseTitle.value.trim(),
                primaryArtist: primaryArtist.value.trim(),
                releaseType: releaseType.value,
                genre: genre.value,
                language: language.value,
                releaseDate: releaseDate.value,
                coverArtURL: coverArtURL,
                upc: upc.value.trim() || null,
                userId: currentUser.uid,
                status: 'draft',
                dsps: selectedDSPs,
                trackCount: tracks.length,
                updatedAt: firebase.firestore.FieldValue.serverTimestamp()
            };
            
            // Create or update release document
            let releaseId;
            
            if (currentReleaseId) {
                // Update existing release
                await firebase.firestore().collection('releases').doc(currentReleaseId).update(releaseData);
                releaseId = currentReleaseId;
            } else {
                // Create new release
                releaseData.createdAt = firebase.firestore.FieldValue.serverTimestamp();
                const releaseRef = await firebase.firestore().collection('releases').add(releaseData);
                releaseId = releaseRef.id;
            }
            
            // Upload tracks
            for (let i = 0; i < tracks.length; i++) {
                const trackIndex = tracks[i].index;
                const trackFile = tracks[i].file;
                
                if (!trackFile) continue;
                
                // Get track data from form
                const trackTitle = document.getElementById(`trackTitle${trackIndex}`).value.trim();
                const trackArtist = document.getElementById(`trackArtist${trackIndex}`).value.trim();
                const trackFeaturing = document.getElementById(`trackFeaturing${trackIndex}`).value.trim();
                const trackISRC = document.getElementById(`trackISRC${trackIndex}`).value.trim();
                const trackExplicit = document.getElementById(`trackExplicit${trackIndex}`).value === 'true';
                const trackLyrics = document.getElementById(`trackLyrics${trackIndex}`).value.trim();
                
                // Upload track file
                const trackRef = firebase.storage().ref().child(`releases/${currentUser.uid}/${releaseId}/${Date.now()}_${i}.${trackFile.name.split('.').pop()}`);
                await trackRef.put(trackFile);
                const trackURL = await trackRef.getDownloadURL();
                
                // Create track document
                const trackData = {
                    title: trackTitle,
                    artist: trackArtist,
                    featuring: trackFeaturing || null,
                    isrc: trackISRC || null,
                    explicit: trackExplicit,
                    lyrics: trackLyrics || null,
                    trackURL: trackURL,
                    trackNumber: i + 1,
                    releaseId: releaseId,
                    userId: currentUser.uid,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                };
                
                await firebase.firestore().collection('releases').doc(releaseId).collection('tracks').add(trackData);
            }
            
            // Show success message and redirect
            alert('Release saved successfully!');
            window.location.href = `release-details.html?id=${releaseId}`;
        } catch (error) {
            console.error('Error submitting release:', error);
            if (uploadError) uploadError.textContent = 'An error occurred while uploading. Please try again.';
            
            // Reset button
            submitBtn.disabled = false;
            submitBtn.textContent = originalBtnText;
        }
    }
    
    // Validate Release Form
    function validateReleaseForm() {
        // Check required fields
        if (!releaseTitle.value.trim()) {
            if (uploadError) uploadError.textContent = 'Please enter a release title.';
            releaseTitle.focus();
            return false;
        }
        
        if (!primaryArtist.value.trim()) {
            if (uploadError) uploadError.textContent = 'Please enter a primary artist.';
            primaryArtist.focus();
            return false;
        }
        
        if (!releaseDate.value) {
            if (uploadError) uploadError.textContent = 'Please select a release date.';
            releaseDate.focus();
            return false;
        }
        
        if (!coverArtUpload.files[0] && !currentReleaseId) {
            if (uploadError) uploadError.textContent = 'Please upload a cover art image.';
            coverArtUpload.focus();
            return false;
        }
        
        // Check if at least one track is added
        if (tracks.length === 0) {
            if (uploadError) uploadError.textContent = 'Please add at least one track.';
            return false;
        }
        
        // Check if all tracks have required fields
        for (let i = 0; i < tracks.length; i++) {
            const trackIndex = tracks[i].index;
            
            const trackTitle = document.getElementById(`trackTitle${trackIndex}`);
            const trackArtist = document.getElementById(`trackArtist${trackIndex}`);
            const trackFile = document.getElementById(`trackFile${trackIndex}`);
            
            if (!trackTitle.value.trim()) {
                if (uploadError) uploadError.textContent = `Please enter a title for Track ${i + 1}.`;
                trackTitle.focus();
                return false;
            }
            
            if (!trackArtist.value.trim()) {
                if (uploadError) uploadError.textContent = `Please enter an artist for Track ${i + 1}.`;
                trackArtist.focus();
                return false;
            }
            
            if (!tracks[i].file && !currentReleaseId) {
                if (uploadError) uploadError.textContent = `Please upload an audio file for Track ${i + 1}.`;
                trackFile.focus();
                return false;
            }
        }
        
        // Check if at least one DSP is selected
        if (selectedDSPs.length === 0) {
            if (uploadError) uploadError.textContent = 'Please select at least one DSP.';
            return false;
        }
        
        return true;
    }
    
    // Load Release for Editing
    async function loadReleaseForEditing(releaseId) {
        try {
            // Get release data
            const releaseDoc = await firebase.firestore().collection('releases').doc(releaseId).get();
            
            if (!releaseDoc.exists) {
                alert('Release not found.');
                window.location.href = 'upload.html';
                return;
            }
            
            const releaseData = releaseDoc.data();
            
            // Check if user owns this release
            if (releaseData.userId !== currentUser.uid) {
                alert('You do not have permission to edit this release.');
                window.location.href = 'releases.html';
                return;
            }
            
            // Set current release ID
            currentReleaseId = releaseId;
            
            // Populate form fields
            releaseTitle.value = releaseData.title || '';
            primaryArtist.value = releaseData.primaryArtist || '';
            releaseType.value = releaseData.releaseType || 'single';
            genre.value = releaseData.genre || '';
            language.value = releaseData.language || '';
            releaseDate.value = releaseData.releaseDate || '';
            upc.value = releaseData.upc || '';
            
            // Show cover art preview
            if (releaseData.coverArtURL && coverArtPreview) {
                coverArtPreview.src = releaseData.coverArtURL;
                coverArtPreview.style.display = 'block';
            }
            
            // Load tracks
            const tracksSnapshot = await firebase.firestore().collection('releases').doc(releaseId).collection('tracks')
                .orderBy('trackNumber', 'asc')
                .get();
            
            if (!tracksSnapshot.empty) {
                // Clear existing track fields
                if (trackUploadContainer) {
                    trackUploadContainer.innerHTML = '';
                }
                
                tracks = [];
                
                // Add track fields for each track
                tracksSnapshot.forEach((doc, index) => {
                    const trackData = doc.data();
                    
                    // Add track upload field
                    addTrackUploadField();
                    
                    // Populate track fields
                    document.getElementById(`trackTitle${index}`).value = trackData.title || '';
                    document.getElementById(`trackArtist${index}`).value = trackData.artist || '';
                    document.getElementById(`trackFeaturing${index}`).value = trackData.featuring || '';
                    document.getElementById(`trackISRC${index}`).value = trackData.isrc || '';
                    document.getElementById(`trackExplicit${index}`).value = trackData.explicit ? 'true' : 'false';
                    document.getElementById(`trackLyrics${index}`).value = trackData.lyrics || '';
                    
                    // Show track file info
                    const fileInfoElement = document.getElementById(`trackFileInfo${index}`);
                    if (fileInfoElement) {
                        fileInfoElement.textContent = 'Audio file already uploaded';
                    }
                });
            }
            
            // Select DSPs
            if (releaseData.dsps) {
                selectedDSPs = [...releaseData.dsps];
                
                // Wait for DSPs to load
                setTimeout(() => {
                    const dspCheckboxes = document.querySelectorAll('.dsp-checkbox');
                    dspCheckboxes.forEach(checkbox => {
                        checkbox.checked = selectedDSPs.includes(checkbox.value);
                    });
                }, 1000);
            }
            
            // Update form title
            const formTitle = document.querySelector('.upload-form-title');
            if (formTitle) {
                formTitle.textContent = 'Edit Release';
            }
            
            // Update submit button
            const submitBtn = uploadForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.textContent = 'Update Release';
            }
        } catch (error) {
            console.error('Error loading release for editing:', error);
            alert('An error occurred while loading the release. Please try again.');
            window.location.href = 'releases.html';
        }
    }
    
    // Load Releases
    async function loadReleases(filter = 'all', searchQuery = '') {
        if (!releasesListElement) return;
        
        try {
            // Show loading state
            releasesListElement.innerHTML = '<tr><td colspan="5" class="text-center"><i class="fas fa-spinner fa-spin"></i> Loading releases...</td></tr>';
            
            // Build query
            let query = firebase.firestore().collection('releases')
                .where('userId', '==', currentUser.uid)
                .orderBy('createdAt', 'desc');
            
            // Apply filter
            if (filter !== 'all') {
                query = query.where('status', '==', filter);
            }
            
            // Get total count for pagination
            const countSnapshot = await query.get();
            const totalReleases = countSnapshot.size;
            totalPages = Math.ceil(totalReleases / pageSize);
            
            // Apply pagination
            const startIndex = (currentPage - 1) * pageSize;
            query = query.limit(pageSize);
            
            if (startIndex > 0) {
                const lastVisibleDoc = await getDocAtIndex(query, startIndex - 1);
                if (lastVisibleDoc) {
                    query = query.startAfter(lastVisibleDoc);
                }
            }
            
            // Get releases
            const releasesSnapshot = await query.get();
            
            if (releasesSnapshot.empty) {
                releasesListElement.innerHTML = '<tr><td colspan="5" class="text-center">No releases found</td></tr>';
                updatePagination(0);
                return;
            }
            
            let html = '';
            
            releasesSnapshot.forEach(doc => {
                const releaseData = doc.data();
                const releaseId = doc.id;
                
                // Format date
                const createdAt = releaseData.createdAt ? new Date(releaseData.createdAt.toDate()) : new Date();
                const formattedDate = createdAt.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                });
                
                // Get status badge class
                let statusBadgeClass = '';
                switch (releaseData.status) {
                    case 'draft':
                        statusBadgeClass = 'draft';
                        break;
                    case 'in_review':
                        statusBadgeClass = 'review';
                        break;
                    case 'approved':
                        statusBadgeClass = 'approved';
                        break;
                    case 'rejected':
                        statusBadgeClass = 'rejected';
                        break;
                    case 'changes_requested':
                        statusBadgeClass = 'changes';
                        break;
                    default:
                        statusBadgeClass = 'draft';
                }
                
                html += `
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center;">
                                <img src="${releaseData.coverArtURL || '../assets/images/default-cover.jpg'}" alt="${releaseData.title}" style="width: 40px; height: 40px; border-radius: 4px; margin-right: 10px;">
                                <div>
                                    <div style="font-weight: 600;">${releaseData.title || 'Untitled Release'}</div>
                                    <div style="font-size: 0.8rem; color: #666;">${releaseData.primaryArtist || 'Unknown Artist'}</div>
                                </div>
                            </div>
                        </td>
                        <td>${releaseData.releaseType || 'Single'}</td>
                        <td>${formattedDate}</td>
                        <td><span class="status-badge ${statusBadgeClass}">${formatStatus(releaseData.status)}</span></td>
                        <td>
                            <div class="action-buttons">
                                <a href="release-details.html?id=${releaseId}" class="action-btn" title="View Details">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="upload.html?id=${releaseId}" class="action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="action-btn delete-release" data-id="${releaseId}" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });
            
            releasesListElement.innerHTML = html;
            
            // Add event listeners for delete buttons
            const deleteButtons = document.querySelectorAll('.delete-release');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const releaseId = this.dataset.id;
                    if (confirm('Are you sure you want to delete this release? This action cannot be undone.')) {
                        deleteRelease(releaseId);
                    }
                });
            });
            
            // Update pagination
            updatePagination(totalReleases);
        } catch (error) {
            console.error('Error loading releases:', error);
            releasesListElement.innerHTML = '<tr><td colspan="5" class="text-center">Error loading releases</td></tr>';
        }
    }
    
    // Get Document at Index
    async function getDocAtIndex(query, index) {
        const snapshot = await query.limit(index + 1).get();
        return snapshot.docs[index];
    }
    
    // Update Pagination
    function updatePagination(totalReleases) {
        if (!releasesPaginationElement) return;
        
        if (totalReleases === 0) {
            releasesPaginationElement.style.display = 'none';
            return;
        }
        
        releasesPaginationElement.style.display = 'flex';
        
        let html = '';
        
        // Previous button
        html += `
            <div class="pagination-item ${currentPage === 1 ? 'disabled' : ''}" data-page="prev">
                <i class="fas fa-chevron-left"></i>
            </div>
        `;
        
        // Page numbers
        const maxPages = Math.min(totalPages, 5);
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(startPage + maxPages - 1, totalPages);
        
        if (endPage - startPage < maxPages - 1) {
            startPage = Math.max(1, endPage - maxPages + 1);
        }
        
        for (let i = startPage; i <= endPage; i++) {
            html += `
                <div class="pagination-item ${i === currentPage ? 'active' : ''}" data-page="${i}">
                    ${i}
                </div>
            `;
        }
        
        // Next button
        html += `
            <div class="pagination-item ${currentPage === totalPages ? 'disabled' : ''}" data-page="next">
                <i class="fas fa-chevron-right"></i>
            </div>
        `;
        
        releasesPaginationElement.innerHTML = html;
        
        // Add event listeners for pagination
        const paginationItems = document.querySelectorAll('.pagination-item');
        paginationItems.forEach(item => {
            item.addEventListener('click', function() {
                if (this.classList.contains('disabled')) return;
                
                const page = this.dataset.page;
                
                if (page === 'prev') {
                    currentPage = Math.max(1, currentPage - 1);
                } else if (page === 'next') {
                    currentPage = Math.min(totalPages, currentPage + 1);
                } else {
                    currentPage = parseInt(page);
                }
                
                // Reload releases with current filter and search
                const filterSelect = document.getElementById('statusFilter');
                const searchInput = document.getElementById('searchInput');
                
                const filter = filterSelect ? filterSelect.value : 'all';
                const searchQuery = searchInput ? searchInput.value.trim() : '';
                
                loadReleases(filter, searchQuery);
            });
        });
    }
    
    // Initialize Filters
    function initializeFilters() {
        const filterSelect = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchInput');
        const searchBtn = document.getElementById('searchBtn');
        
        if (filterSelect) {
            filterSelect.addEventListener('change', function() {
                currentPage = 1;
                const searchQuery = searchInput ? searchInput.value.trim() : '';
                loadReleases(this.value, searchQuery);
            });
        }
        
        if (searchBtn && searchInput) {
            searchBtn.addEventListener('click', function() {
                currentPage = 1;
                const filter = filterSelect ? filterSelect.value : 'all';
                loadReleases(filter, searchInput.value.trim());
            });
            
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    currentPage = 1;
                    const filter = filterSelect ? filterSelect.value : 'all';
                    loadReleases(filter, this.value.trim());
                }
            });
        }
    }
    
    // Delete Release
    async function deleteRelease(releaseId) {
        try {
            // Delete release document
            await firebase.firestore().collection('releases').doc(releaseId).delete();
            
            // Reload releases
            loadReleases();
            
            alert('Release deleted successfully!');
        } catch (error) {
            console.error('Error deleting release:', error);
            alert('An error occurred while deleting the release. Please try again.');
        }
    }
    
    // Load Release Details
    async function loadReleaseDetails(releaseId) {
        try {
            // Get release data
            const releaseDoc = await firebase.firestore().collection('releases').doc(releaseId).get();
            
            if (!releaseDoc.exists) {
                alert('Release not found.');
                window.location.href = 'releases.html';
                return;
            }
            
            const releaseData = releaseDoc.data();
            
            // Check if user owns this release
            if (releaseData.userId !== currentUser.uid) {
                alert('You do not have permission to view this release.');
                window.location.href = 'releases.html';
                return;
            }
            
            // Update release details
            if (releaseDetailsCoverArt) {
                releaseDetailsCoverArt.src = releaseData.coverArtURL || '../assets/images/default-cover.jpg';
            }
            
            if (releaseDetailsTitle) {
                releaseDetailsTitle.textContent = releaseData.title || 'Untitled Release';
            }
            
            if (releaseDetailsArtist) {
                releaseDetailsArtist.textContent = releaseData.primaryArtist || 'Unknown Artist';
            }
            
            if (releaseDetailsType) {
                releaseDetailsType.textContent = releaseData.releaseType || 'Single';
            }
            
            if (releaseDetailsGenre) {
                releaseDetailsGenre.textContent = releaseData.genre || 'N/A';
            }
            
            if (releaseDetailsLanguage) {
                releaseDetailsLanguage.textContent = releaseData.language || 'N/A';
            }
            
            if (releaseDetailsReleaseDate) {
                releaseDetailsReleaseDate.textContent = releaseData.releaseDate || 'N/A';
            }
            
            if (releaseDetailsUPC) {
                releaseDetailsUPC.textContent = releaseData.upc || 'N/A';
            }
            
            if (releaseDetailsStatus) {
                releaseDetailsStatus.textContent = formatStatus(releaseData.status);
                
                // Set status badge class
                let statusBadgeClass = '';
                switch (releaseData.status) {
                    case 'draft':
                        statusBadgeClass = 'draft';
                        break;
                    case 'in_review':
                        statusBadgeClass = 'review';
                        break;
                    case 'approved':
                        statusBadgeClass = 'approved';
                        break;
                    case 'rejected':
                        statusBadgeClass = 'rejected';
                        break;
                    case 'changes_requested':
                        statusBadgeClass = 'changes';
                        break;
                    default:
                        statusBadgeClass = 'draft';
                }
                
                releaseDetailsStatus.className = `status-badge ${statusBadgeClass}`;
            }
            
            if (releaseDetailsSubmittedDate) {
                if (releaseData.submittedAt) {
                    const submittedAt = new Date(releaseData.submittedAt.toDate());
                    releaseDetailsSubmittedDate.textContent = submittedAt.toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'short', 
                        day: 'numeric' 
                    });
                } else {
                    releaseDetailsSubmittedDate.textContent = 'Not submitted yet';
                }
            }
            
            // Load tracks
            if (releaseDetailsTrackList) {
                const tracksSnapshot = await firebase.firestore().collection('releases').doc(releaseId).collection('tracks')
                    .orderBy('trackNumber', 'asc')
                    .get();
                
                if (tracksSnapshot.empty) {
                    releaseDetailsTrackList.innerHTML = '<p>No tracks found</p>';
                } else {
                    let html = '';
                    
                    tracksSnapshot.forEach(doc => {
                        const trackData = doc.data();
                        
                        html += `
                            <div class="track-item">
                                <div class="track-number">${trackData.trackNumber}</div>
                                <div class="track-info">
                                    <div class="track-title">${trackData.title}</div>
                                    <div class="track-artist">${trackData.artist}${trackData.featuring ? ` feat. ${trackData.featuring}` : ''}</div>
                                </div>
                                <div class="track-actions">
                                    ${trackData.explicit ? '<span class="explicit-badge">E</span>' : ''}
                                    <audio controls src="${trackData.trackURL}"></audio>
                                </div>
                            </div>
                        `;
                    });
                    
                    releaseDetailsTrackList.innerHTML = html;
                }
            }
            
            // Load DSPs
            if (releaseDetailsDSPs) {
                if (!releaseData.dsps || releaseData.dsps.length === 0) {
                    releaseDetailsDSPs.innerHTML = '<p>No DSPs selected</p>';
                } else {
                    // Get DSP data
                    const dspsSnapshot = await firebase.firestore().collection('dsps')
                        .where(firebase.firestore.FieldPath.documentId(), 'in', releaseData.dsps)
                        .get();
                    
                    if (dspsSnapshot.empty) {
                        releaseDetailsDSPs.innerHTML = '<p>No DSPs found</p>';
                    } else {
                        let html = '<div class="dsp-grid">';
                        
                        dspsSnapshot.forEach(doc => {
                            const dspData = doc.data();
                            
                            html += `
                                <div class="dsp-item">
                                    <img src="${dspData.logoURL || '../assets/images/dsp-placeholder.png'}" alt="${dspData.name}">
                                    <span>${dspData.name}</span>
                                </div>
                            `;
                        });
                        
                        html += '</div>';
                        
                        releaseDetailsDSPs.innerHTML = html;
                    }
                }
            }
            
            // Add event listeners for action buttons
            const submitBtn = document.getElementById('submitReleaseBtn');
            const editBtn = document.getElementById('editReleaseBtn');
            const deleteBtn = document.getElementById('deleteReleaseBtn');
            
            if (submitBtn) {
                // Show/hide submit button based on status
                if (releaseData.status === 'draft' || releaseData.status === 'changes_requested') {
                    submitBtn.style.display = 'inline-block';
                    
                    submitBtn.addEventListener('click', function() {
                        if (confirm('Are you sure you want to submit this release for review? You will not be able to make changes while it is being reviewed.')) {
                            submitReleaseForReview(releaseId);
                        }
                    });
                } else {
                    submitBtn.style.display = 'none';
                }
            }
            
            if (editBtn) {
                // Show/hide edit button based on status
                if (releaseData.status === 'draft' || releaseData.status === 'changes_requested') {
                    editBtn.style.display = 'inline-block';
                } else {
                    editBtn.style.display = 'none';
                }
            }
            
            if (deleteBtn) {
                deleteBtn.addEventListener('click', function() {
                    if (confirm('Are you sure you want to delete this release? This action cannot be undone.')) {
                        deleteRelease(releaseId);
                        window.location.href = 'releases.html';
                    }
                });
            }
        } catch (error) {
            console.error('Error loading release details:', error);
            alert('An error occurred while loading the release details. Please try again.');
            window.location.href = 'releases.html';
        }
    }
    
    // Submit Release for Review
    async function submitReleaseForReview(releaseId) {
        try {
            // Update release status
            await firebase.firestore().collection('releases').doc(releaseId).update({
                status: 'in_review',
                submittedAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            
            // Reload page
            window.location.reload();
        } catch (error) {
            console.error('Error submitting release for review:', error);
            alert('An error occurred while submitting the release for review. Please try again.');
        }
    }
    
    // Helper Functions
    function formatStatus(status) {
        switch (status) {
            case 'draft':
                return 'Draft';
            case 'in_review':
                return 'In Review';
            case 'approved':
                return 'Approved';
            case 'rejected':
                return 'Rejected';
            case 'changes_requested':
                return 'Changes Requested';
            case 'live':
                return 'Live';
            default:
                return 'Draft';
        }
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
});
